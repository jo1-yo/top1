// First-run: open the onboarding page right after install.
chrome.runtime.onInstalled.addListener(function (d) {
  if (d.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
});

// Alt+Shift+K toggles the coach in the current tab.
chrome.commands.onCommand.addListener(function (cmd) {
  if (cmd !== "toggle-coach") return;
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "toggle" }).catch(function () {});
  });
});
