// Shared by popup + welcome: start a lesson in the current tab if that tab is the lesson's AI, otherwise
// open that AI with the lesson waiting. No "tabs" permission needed: we just ask the active tab, and only
// our content script can answer (it says no if the lesson belongs to a different AI).
function startLesson(lessonId, openNew, done) {
  var site = coachTrackOf(lessonId);
  chrome.storage.local.get(["top1"], function (r) {
    var s = r.top1 || {};
    var openSite = function () {
      // content.js on that site picks up `pending` when it loads.
      s.pending = lessonId; s.open = true; s.track = site;
      chrome.storage.local.set({ top1: s }, function () {
        chrome.tabs.create({ url: COACH_SITES[site].home });
        done && done();
      });
    };
    if (openNew) return openSite();
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs[0]) return openSite();
      chrome.tabs.sendMessage(tabs[0].id, { type: "start", lessonId: lessonId }, function (res) {
        if (chrome.runtime.lastError || !res || !res.ok) return openSite();
        done && done();
      });
    });
  });
}
