// Shared by popup + welcome: start a lesson in the current tab if the coach lives there, otherwise open an AI.
// No "tabs" permission needed: we just ask the active tab; only our content script can answer.
var AI_SITES = { chatgpt: "https://chatgpt.com/", claude: "https://claude.ai/new", grok: "https://grok.com/", gemini: "https://gemini.google.com/app" };

function startLesson(lessonId, site, done) {
  chrome.storage.local.get(["top1"], function (r) {
    var s = r.top1 || {};
    var openSite = function () {
      // Remember the lesson; content.js picks up `pending` when the AI site loads.
      s.pending = lessonId; s.open = true;
      chrome.storage.local.set({ top1: s }, function () {
        chrome.tabs.create({ url: AI_SITES[site || s.site || "chatgpt"] });
        done && done();
      });
    };
    if (site) return openSite();
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs[0]) return openSite();
      chrome.tabs.sendMessage(tabs[0].id, { type: "start", lessonId: lessonId }, function (res) {
        if (chrome.runtime.lastError || !res || !res.ok) return openSite();
        done && done();
      });
    });
  });
}
