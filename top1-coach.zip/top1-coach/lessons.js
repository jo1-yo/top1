// Curriculum = units → lessons → micro-steps. Pure data: add lessons without touching content.js.
//
// Lesson anatomy (keep every lesson to this shape, ~2 minutes):
//   Why   one line            (say)
//   See   before → after      (contrast)
//   Do    on YOUR real task, inside the real tool   (insert + wait-send, or click steps)
//   Keep  the lesson's first `insert` prompt is saved to the user's Kit on completion
//   Own   `detect` (regex) marks the skill "mastered" once the user does it 3× unprompted
//
// Copy rule: one short line per step. If it needs two sentences, it's two steps.
//
// Step types
//   say        text only
//   contrast   { bad, good } before/after, one line each
//   goto       "Open" → opens `url` (progress carries over to the new site)
//   spotlight  dim the page, highlight `target`
//   click      highlight `target`, auto-advance when the user clicks it
//   insert     put `prompt` into the AI chat box
//   wait-send  advance when the user sends the chat message
//   wait-url   advance when location.href matches regex `url`
//
// target: "composer" | { text: "Visible label" } | { sel: ["css", ...] }   (not found → text + Done)
// site:   regex on hostname. Elsewhere → the coach offers to open it.

var COACH_UNITS = [
  { id: "prompt", title: "Prompt" },
  { id: "think", title: "Think" },
  { id: "context", title: "Context" },
  { id: "verify", title: "Verify" },
  { id: "tools", title: "Tools" },
  { id: "connect", title: "Connect" },
  { id: "ship", title: "Ship" },
  { id: "agents", title: "Agents" },
  { id: "cost", title: "Cost" }
];

var AI_CHAT = "chatgpt\\.com|claude\\.ai|gemini\\.google\\.com";
var GH = "github\\.com";
var CLAUDE = "claude\\.ai";

// shorthand for the most common "Do" pair
function doIt(prompt, text, sendText) {
  return [
    { type: "insert", site: AI_CHAT, target: "composer", text: text || "Edit the [brackets].", prompt: prompt },
    { type: "wait-send", site: AI_CHAT, target: "composer", text: sendText || "Send." }
  ];
}

var COACH_LESSONS = [
  // ───────── Prompt: how to ask ─────────
  {
    id: "brief", unit: "prompt", title: "Brief, don't ask", xp: 20,
    detect: "(you are|act as)[\\s\\S]{0,400}(goal|context|constraint|output|format)",
    steps: [
      { type: "say", text: "Role. Goal. Context. Constraints. Format." },
      { type: "contrast", bad: "Make my resume better.", good: "You're a recruiter. Rewrite this bullet for a PM internship. 2 lines, quantified." },
      ...doIt(
        "You are a [senior recruiter at a top tech company].\n" +
        "Goal: [rewrite my resume bullet for a PM internship].\n" +
        "Context: [sophomore CS major; bullet: \"Built a club website\"].\n" +
        "Constraints: [2 lines max, quantified, no buzzwords].\n" +
        "Output: 3 versions, then pick one and say why."),
      {
        type: "insert", site: AI_CHAT, target: "composer", text: "Now get graded.",
        prompt: "Grade the prompt I just sent: role, goal, context, constraints, format. 1 point each. Then rewrite it to 5/5."
      },
      { type: "wait-send", site: AI_CHAT, target: "composer", text: "Send." }
    ]
  },
  {
    id: "examples", unit: "prompt", title: "Show, don't describe", xp: 20,
    detect: "example 1|for example:|match the (style|tone|format)|like this:",
    steps: [
      { type: "say", text: "One example beats ten adjectives." },
      { type: "contrast", bad: "Write it casual and punchy.", good: "Match the style of these two posts: …" },
      ...doIt(
        "Write [a LinkedIn post about my internship].\n" +
        "Match the style of these examples exactly:\n\n" +
        "Example 1: [paste]\nExample 2: [paste]\n\n" +
        "First list what they have in common. Then write.")
    ]
  },
  {
    id: "interview", unit: "prompt", title: "Let it ask you", xp: 20,
    detect: "interview me|ask me (\\d+|a few|some)? ?questions|one question at a time",
    steps: [
      { type: "say", text: "Unsure what context matters? Let the AI ask." },
      { type: "contrast", bad: "What should I do this summer?", good: "Interview me first, one question at a time. Then recommend." },
      ...doIt(
        "I want to [plan my summer: internship, research, or a project].\n" +
        "Interview me first: one question at a time, max 6. Then recommend.",
        "Edit the [task].", "Send, then answer.")
    ]
  },
  {
    id: "ten", unit: "prompt", title: "Ask for ten, keep one", xp: 20,
    detect: "\\b(10|ten|20|twenty)\\b[\\s\\S]{0,40}(different|options|ideas|versions|variations)",
    steps: [
      { type: "say", text: "First ideas are average. Ask for many, then choose." },
      { type: "contrast", bad: "Give me a name for my event.", good: "10 very different names. 3 weird ones. Pick 2." },
      ...doIt(
        "Give me 10 very different [names for my club's event].\n" +
        "Make 3 of them weird. Number them.\n" +
        "Then pick the best 2 and say why.")
    ]
  },

  // ───────── Think: use AI to think better, not less ─────────
  {
    id: "expert", unit: "think", title: "Think like an expert", xp: 25,
    detect: "(steelman|attack|argue against|critique) (each|it|them|this)",
    steps: [
      { type: "say", text: "Ask for options. Then make it argue." },
      { type: "contrast", bad: "How do I grow my club?", good: "3 approaches a top marketer would weigh. Attack each. Pick one." },
      ...doIt(
        "Act as a top 1% [growth marketer]. Problem: [grow my club from 40 to 200 members].\n" +
        "1) 3 different approaches. 2) Attack each. 3) Pick one, 7-day plan.")
    ]
  },
  {
    id: "premortem", unit: "think", title: "Pre-mortem", xp: 25,
    detect: "pre-?mortem|(it|this|the plan) (has )?failed|why (it|this) (would|will|might) fail",
    steps: [
      { type: "say", text: "Imagine it already failed. Ask why." },
      ...doIt(
        "Here's my plan: [plan].\n" +
        "It's 3 months later and it failed. Write the most likely story of why.\n" +
        "Then the 3 cheapest ways to prevent it.")
    ]
  },
  {
    id: "rubric", unit: "think", title: "Define good first", xp: 25,
    detect: "rubric|scor(e|ing) (it|yourself|against)|grading criteria",
    steps: [
      { type: "say", text: "Set the bar before it writes." },
      { type: "contrast", bad: "Write my cover letter.", good: "Make a 5-point rubric. Write. Score. Revise until 4/5+." },
      ...doIt(
        "Before writing [my cover letter for X], create a 5-point rubric a hiring manager would use.\n" +
        "Then write it, score it against the rubric, and revise until every point is 4/5+.")
    ]
  },
  {
    id: "tutor", unit: "think", title: "Tutor, not answer key", xp: 25,
    detect: "socratic|don'?t (just )?give (me )?(the )?answers?|quiz me|test me",
    steps: [
      { type: "say", text: "Learning? Make it teach, not tell." },
      { type: "contrast", bad: "Solve this problem.", good: "Don't solve it. Ask me questions until I can." },
      ...doIt(
        "Be my Socratic tutor for [derivatives in calculus].\n" +
        "Don't give answers. One question at a time. Check my reasoning. Hint when I'm stuck.\n" +
        "End with 3 practice problems.",
        "Edit the [topic].", "Send, then answer.")
    ]
  },

  // ───────── Context: the real 1% skill ─────────
  {
    id: "voice", unit: "context", title: "Talk, don't type", xp: 25,
    steps: [
      { type: "say", text: "You talk 3× faster than you type. Ramble." },
      {
        type: "insert", site: AI_CHAT, target: "composer", text: "Then tap the mic and talk for a minute.",
        prompt:
          "I'm going to brain-dump. Don't answer yet.\n" +
          "Turn it into: goal, constraints, open questions. Then ask me the one question that matters most.\n\n"
      },
      { type: "wait-send", site: AI_CHAT, target: "composer", text: "Talk. Then send." }
    ]
  },
  {
    id: "project", unit: "context", title: "A Project per class", xp: 30,
    steps: [
      { type: "say", text: "Files + instructions, remembered in every chat." },
      { type: "goto", site: CLAUDE, url: "https://claude.ai/projects", text: "In Claude." },
      { type: "click", site: CLAUDE, target: { text: "New project" }, text: "New project." },
      { type: "wait-url", site: CLAUDE, url: "claude\\.ai/project/", text: "Name it after a class." },
      { type: "say", text: "Add your syllabus and notes." }
    ]
  },
  {
    id: "about-me", unit: "context", title: "Write yourself down once", xp: 30,
    steps: [
      { type: "say", text: "One context file about you. Reused everywhere." },
      ...doIt(
        "Interview me (max 8 questions, one at a time) to write a context file about me:\n" +
        "who I am, goals, how I like answers, what to avoid.\n" +
        "Output one copyable block under 200 words.",
        "Send as-is.", "Send, then answer."),
      { type: "say", text: "Paste it into custom instructions." }
    ]
  },
  {
    id: "fresh", unit: "context", title: "Fresh chat, same context", xp: 25,
    detect: "handoff|summari[sz]e (this|our) (chat|conversation)",
    steps: [
      { type: "say", text: "Long chats get worse. Restart with a summary." },
      ...doIt(
        "Summarize this conversation as a handoff for a new chat:\n" +
        "goal, decisions made, current state, open questions, next step.\nOne copyable block.",
        "Use in a long chat.", "Send. Paste into a new chat.")
    ]
  },

  // ───────── Verify: confident ≠ correct ─────────
  {
    id: "cite", unit: "verify", title: "Make it cite", xp: 25,
    detect: "(source|cite|citation)s?[\\s\\S]{0,80}(confidence|check|verify)|say .?not sure",
    steps: [
      { type: "say", text: "Confident isn't correct." },
      ...doIt(
        "Answer [question]. Then list every factual claim you made.\n" +
        "For each: a source I can check, and your confidence (high / med / low).\n" +
        "Say \"not sure\" instead of guessing."),
      { type: "say", text: "Open two sources. Do they actually say that?" }
    ]
  },
  {
    id: "second-opinion", unit: "verify", title: "Get a second opinion", xp: 25,
    detect: "another (ai|model)|skeptical reviewer",
    steps: [
      { type: "say", text: "Different models, different blind spots." },
      ...doIt(
        "Another AI gave me this answer:\n\n[PASTE]\n\n" +
        "You're a skeptical reviewer. What's wrong, missing, or overstated? Be specific.",
        "Paste an answer from a different AI.")
    ]
  },
  {
    id: "integrity", unit: "verify", title: "What not to outsource", xp: 20,
    steps: [
      { type: "say", text: "If AI does the thinking, you don't learn it." },
      { type: "contrast", bad: "Write my essay.", good: "Critique my draft. Quiz me. Explain what I got wrong." },
      { type: "say", text: "Check each class's AI policy. Unsure? Disclose." }
    ]
  },

  // ───────── Tools: beyond the text box ─────────
  {
    id: "screenshot", unit: "tools", title: "Screenshot anything", xp: 20,
    steps: [
      { type: "say", text: "Show it. Don't describe it." },
      { type: "say", text: "Mac: ⌘⌃⇧4 copies a screenshot. Paste it in the chat." },
      ...doIt(
        "Here's a screenshot of [an error / a chart / a problem set].\n" +
        "Explain what's going on in one paragraph. Then what I should do next.",
        "Paste a screenshot, then insert this.")
    ]
  },
  {
    id: "research", unit: "tools", title: "Deep research, checked", xp: 30,
    detect: "separate facts from|flag anything older",
    steps: [
      { type: "say", text: "Big question? Use research mode. Then verify." },
      { type: "say", text: "Turn on Research in your AI's tools menu." },
      ...doIt(
        "Research [the job market for UX interns this year].\n" +
        "1-page brief with sources. Separate facts from your inferences.\n" +
        "Flag anything older than 12 months.")
    ]
  },
  {
    id: "build", unit: "tools", title: "Build, don't chat", xp: 30,
    detect: "build (me )?(an? )?(interactive|app|tool|tracker|calculator|game)",
    steps: [
      { type: "say", text: "Ask for a tool, not an answer." },
      { type: "contrast", bad: "Explain these notes.", good: "Build me a flashcard app from these notes." },
      ...doIt(
        "Build me an interactive flashcard app (single page) from these notes:\n[paste notes]\n" +
        "Flip on click. Shuffle. Track what I got wrong."),
      { type: "say", text: "Claude: Artifacts. ChatGPT: Canvas." }
    ]
  },

  // ───────── Connect: AI + your stuff ─────────
  {
    id: "connector", unit: "connect", title: "Connect Google Drive", xp: 35,
    steps: [
      { type: "say", text: "Let AI read your files. Only when asked." },
      { type: "goto", site: CLAUDE, url: "https://claude.ai/new#settings/connectors", text: "Claude settings." },
      { type: "click", site: CLAUDE, target: { text: "Customize" }, text: "Customize." },
      { type: "say", site: CLAUDE, text: "Google Drive → Connect." }
    ]
  },
  {
    id: "ask-your-stuff", unit: "connect", title: "Ask your own files", xp: 30,
    detect: "(in|from|search) my (google )?(drive|docs|calendar|gmail|notion)",
    steps: [
      { type: "goto", site: CLAUDE, url: "https://claude.ai/new", text: "New Claude chat." },
      {
        type: "insert", site: CLAUDE, target: "composer", text: "Edit the [brackets].",
        prompt:
          "Find [my latest resume] in my Google Drive.\n" +
          "Compare it to [job post]. 3 gaps, 3 rewritten bullets. Cite the file."
      },
      { type: "wait-send", site: CLAUDE, target: "composer", text: "Send." },
      { type: "say", text: "That's MCP. Same plug, every tool." }
    ]
  },

  // ───────── Ship: make real things ─────────
  {
    id: "gh-repo", unit: "ship", title: "Your first repo", xp: 30,
    steps: [
      { type: "say", text: "A folder in the cloud, with history." },
      { type: "goto", site: GH, url: "https://github.com/new", text: "GitHub. Sign up free." },
      { type: "spotlight", site: GH, target: { sel: ["#repository-name-input", "input[aria-label='Repository name']", "input[name='repository[name]']"] }, text: "Name: <b>username.github.io</b>" },
      { type: "click", site: GH, target: { text: "Create repository" }, text: "Public. Add README. Create." },
      { type: "wait-url", site: GH, url: "github\\.com/[^/]+/[^/?#]+/?$", text: "Creating…" }
    ]
  },
  {
    id: "gh-site", unit: "ship", title: "Ship a website", xp: 40,
    steps: [
      { type: "goto", site: AI_CHAT, url: "https://chatgpt.com/", text: "Let AI write it." },
      ...doIt(
        "Write one self-contained index.html (inline CSS) for my personal site.\n" +
        "Me: [name, school, 2 projects, links]. Style: [minimal, mobile-first].\nCode only.",
        null, "Send. Save as index.html."),
      { type: "say", text: "Back to your repo." },
      { type: "click", site: GH, target: { text: "Add file" }, text: "Add file → Upload → Commit." },
      { type: "say", site: GH, text: "Live at username.github.io." }
    ]
  },
  {
    id: "claude-code", unit: "ship", title: "AI that edits files", xp: 30,
    steps: [
      { type: "say", text: "Claude Code works in your folders. Reads, writes, runs, pushes." },
      { type: "goto", url: "https://claude.com/claude-code", text: "Install. Then improve your site with it." }
    ]
  },

  // ───────── Agents: delegate, then review ─────────
  {
    id: "agent-loop", unit: "agents", title: "Your first agent", xp: 40,
    detect: "agent loop|done when:",
    steps: [
      { type: "say", text: "Plan. Do. Check. Repeat." },
      ...doIt(
        "Run as an agent loop.\nGoal: [10 startups hiring design interns in NYC + 3 cold emails].\n" +
        "Done when: [table of 10 with why-fit, 3 emails under 120 words].\n" +
        "Each turn: plan as checkboxes → do next step → check vs. done → wait for \"continue\".\n" +
        "Mark anything unverifiable as UNVERIFIED.",
        "Edit the [goal]. Reply \"continue\".")
    ]
  },
  {
    id: "workflow", unit: "agents", title: "Save what worked", xp: 30,
    detect: "reusable (workflow|prompt|template)",
    steps: [
      { type: "say", text: "A great chat, made repeatable." },
      ...doIt(
        "Turn this conversation into a reusable workflow:\n" +
        "name · inputs as [brackets] · the exact prompt · a quality checklist.\nOne copyable block.",
        "Use after a good chat.", "Send."),
      { type: "say", text: "Keep it as a Project instruction or a Claude Skill." }
    ]
  },
  {
    id: "schedule", unit: "agents", title: "Runs while you sleep", xp: 40,
    steps: [
      { type: "goto", site: CLAUDE, url: "https://claude.ai/new", text: "Claude." },
      { type: "click", site: CLAUDE, target: { text: "Scheduled" }, text: "Scheduled." },
      { type: "say", site: CLAUDE, text: "Sundays 8pm: next week's deadlines, from Calendar + Drive." }
    ]
  },
  {
    id: "parallel", unit: "agents", title: "Manage, don't chat", xp: 35,
    detect: "parallel agents?|one of \\d+ (parallel )?agents",
    steps: [
      { type: "say", text: "Top users run several AIs at once. They review; they don't wait." },
      { type: "say", text: "Three tabs. Three tasks. Check back in ten minutes." },
      ...doIt(
        "You're one of 3 parallel agents. Your task only: [research 5 competitors of X].\n" +
        "Work until done. Then a 5-line summary and what you need from me.")
    ]
  },

  // ───────── Cost: max leverage, min spend ─────────
  {
    id: "cheap", unit: "cost", title: "Draft cheap, check smart", xp: 25,
    detect: "(smaller|cheaper|another) model wrote",
    steps: [
      { type: "say", text: "Free model drafts. Premium model reviews." },
      ...doIt(
        "A smaller model wrote this. Don't rewrite it.\n" +
        "3 weakest points, one line each, then minimal edits.\n\n[DRAFT]",
        "Paste the draft at [DRAFT].")
    ]
  },
  {
    id: "right-model", unit: "cost", title: "Right model, right job", xp: 20,
    steps: [
      { type: "say", text: "Fast model: rewrites, summaries, chat." },
      { type: "say", text: "Thinking model: math, code, plans, hard calls." },
      { type: "say", text: "Next task: pick the model on purpose." }
    ]
  }
];

if (typeof window !== "undefined") { window.COACH_LESSONS = COACH_LESSONS; window.COACH_UNITS = COACH_UNITS; }
