// Top1 curriculum: one track per AI. ChatGPT is taught inside ChatGPT, Claude inside Claude, and so on.
// Default learner: a CS sophomore hunting a summer 2027 SWE internship. Every example is that job.
//
// Track = units → lessons → micro-steps. Pure data: add lessons without touching content.js.
//   Why   say              one line
//   See   contrast         before → after
//   Find  click/spotlight  where it lives in the real UI (profile → Settings, +, the sidebar)
//   Do    insert           a filled-in Example that runs as-is, or Yours (the template)
//   Look  notice           what a good answer has: the actual learning
//   Keep  the template lands in the Kit.   Own: `detect` regex → mastered after 3 unprompted uses.
// Copy rule: one short line per step.
//
// Steps:  say · contrast {bad, good} · goto {url} · spotlight {target} · click {target, missing?}
//         insert {example?, prompt} · wait-send · notice {items} · wait-url {url}
//         copy {copy, target?}        text to paste into a settings field (not the chat box)
//         terminal {cmd: {mac, win}}  open the terminal, paste, run
// target: "composer" | { sel: [css…], text: ["Label", "标签"], any?, wrap? }
//         any → also plain text labels (exact).  wrap: "row" (the setting's row) or a selector ("section").
//         Labels list the English and Chinese UI. Not found → the step says `missing` (or a default).
// Lesson: { id: "<site>/<name>", unit, title, xp, steps, detect?, then?: { label, lesson } }
//         then → a second button on the lesson's done card (lesson 1 offers "More prompting").
// Unit:   { id, title, optional? }   Continue skips optional units.

var COACH_SITES = {
  chatgpt: { name: "ChatGPT", host: "chatgpt\\.com", home: "https://chatgpt.com/" },
  claude: { name: "Claude", host: "claude\\.ai", home: "https://claude.ai/new" },
  grok: { name: "Grok", host: "grok\\.com", home: "https://grok.com/" },
  gemini: { name: "Gemini", host: "gemini\\.google\\.com", home: "https://gemini.google.com/app" }
};
var GH = "github\\.com";

// ───────── shared building blocks ─────────

var ABOUT_ME =
  "About me: CS sophomore applying to SWE internships for summer 2027. Python and Java; learning React.\n" +
  "How to answer: direct, no filler. For code, show the fix, then why in two lines.\n" +
  "If you're not sure, say so. Ask before assuming.";

var PROJECT_INSTRUCTIONS =
  "I'm a CS sophomore applying to SWE internships for summer 2027.\n" +
  "Every answer: concrete, short, aimed at getting interviews.\n" +
  "When I share a job post, compare it with my resume (in this project's files).\n" +
  "Track applications as a table: company | role | status | deadline | next step.";

var JOB_POST =
  "\"Software Engineering Intern, Summer 2027. Python or Java. Data structures and algorithms. " +
  "REST APIs. Git. Bonus: React, SQL, cloud.\"";

// Do → Look: insert (example + template), send, then what to look for.
function practice(site, o) {
  var steps = [
    { type: "insert", site: site, target: "composer", text: o.text || "Run the example. Or switch to Yours.", example: o.example, prompt: o.prompt },
    { type: "wait-send", site: site, target: "composer", text: o.send || "Send. Then read the answer." }
  ];
  if (o.look) steps.push({ type: "notice", items: o.look });
  return steps;
}

function units() {
  return [
    { id: "start", title: "Start" },
    { id: "prompting", title: "More prompting", optional: true },
    { id: "setup", title: "Set up" },
    { id: "tools", title: "Tools" },
    { id: "organize", title: "Organize" },
    { id: "connect", title: "Connect" },
    { id: "code", title: "Code" }
  ];
}

// Lesson 1 everywhere: the one prompting habit that matters most. Then straight into the product.
function brief(s) {
  var site = COACH_SITES[s];
  return {
    id: s + "/brief", unit: "start", title: "Brief, don't ask", xp: 20,
    detect: "(you are|act as)[\\s\\S]{0,400}(goal|context|constraint|output|format)",
    then: { label: "More prompting", lesson: s + "/examples" },
    steps: [
      { type: "say", text: "Role. Goal. Context. Constraints. Format." },
      { type: "contrast", bad: "Fix my resume.", good: "You're a SWE recruiter. Rewrite my 3 bullets: verb first, one number each, under 20 words." },
      ...practice(site.host, {
        example:
          "You are a recruiter who hires SWE interns at a big tech company.\n" +
          "Goal: rewrite my 3 resume bullets for summer 2027 SWE internships.\n" +
          "Context: I'm a CS sophomore. My bullets:\n" +
          "- Made a website for my school club\n" +
          "- Did a Python project for my data structures class\n" +
          "- Helped build an app at a hackathon\n" +
          "Constraints: strong verb first, one number each, under 20 words, no buzzwords. If you need a number, ask me. Don't invent one.\n" +
          "Output: a table: old | new | what changed.",
        prompt: "You are a [role].\nGoal: [what you want].\nContext: [who you are, what you have].\nConstraints: [length, tone, must / must not].\nOutput: [format].",
        look: ["It asked for numbers instead of inventing them.", "Every bullet starts with a verb.", "Now compare: “fix my resume”."]
      })
    ]
  };
}

// Optional unit: more prompting techniques, same job, same site.
function prompting(s) {
  var h = COACH_SITES[s].host;
  return [
    {
      id: s + "/examples", unit: "prompting", title: "Show, don't describe", xp: 20,
      detect: "match the (style|tone|format)|in the style of these|like this:",
      steps: [
        { type: "say", text: "Two examples beat ten adjectives." },
        { type: "contrast", bad: "Write a catchy LinkedIn headline.", good: "Write 5 in the style of these two. Under 70 characters." },
        ...practice(h, {
          example:
            "Write 5 LinkedIn headlines for me in the style of these two:\n" +
            "1) \"CS @ State · Building tools 2,000 students use · Python, React\"\n" +
            "2) \"SWE intern '26 · I ship small things fast\"\n" +
            "About me: CS sophomore. Python and Java. Built my club's website (400 visits a month) and a hackathon app. Looking for summer 2027 SWE internships.\n" +
            "Under 70 characters each. No emoji.",
          prompt: "Write [N] [things] in the style of these examples:\n1) [example]\n2) [example]\nAbout me: [context].\n[Constraints].",
          look: ["It copied the pattern, not the words.", "Pick one. Ask for 5 more like it."]
        })
      ]
    },
    {
      id: s + "/interview", unit: "prompting", title: "Let it ask you", xp: 20,
      detect: "interview me|ask me (\\d+|a few|some)? ?questions|one question at a time",
      steps: [
        { type: "say", text: "Don't know what to say? Let it ask." },
        ...practice(h, {
          example:
            "Interview me, one question at a time (8 max), to write my answer to “Tell me about yourself” for SWE intern interviews.\n" +
            "Then write a 60-second answer in my words, not yours.",
          prompt: "Interview me, one question at a time ([N] max), to [goal].\nThen [what to produce], in my words.",
          look: ["One question at a time.", "The answer sounds like you."]
        })
      ]
    },
    {
      id: s + "/debug", unit: "prompting", title: "Debug your homework", xp: 25,
      detect: "(point to|find) the (bug|error)|buggy line|hint before",
      steps: [
        { type: "say", text: "Get the bug found. Keep the learning yours." },
        { type: "contrast", bad: "Fix my code.", good: "Point to the buggy line. Explain why. Hint before the fix." },
        ...practice(h, {
          example:
            "I'm learning Python. This should return the average of a list, but average([2, 4, 6]) returns 3.33 instead of 4.0.\n" +
            "Don't rewrite it. Point to the buggy line, explain why in one sentence, and give me a hint before the fix.\n\n" +
            "def average(nums):\n    total = 0\n    for i in range(1, len(nums)):\n        total += nums[i]\n    return total / len(nums)",
          prompt:
            "I'm learning [language]. This should [expected result], but [what happens instead].\n" +
            "Don't rewrite it. Point to the buggy line, explain why in one sentence, and give me a hint before the fix.\n\n[paste code]",
          look: ["It named the exact line.", "Why came before the fix.", "Ask “why” until you could explain it to a friend."]
        })
      ]
    },
    {
      id: s + "/premortem", unit: "prompting", title: "Pre-mortem", xp: 25,
      detect: "pre-?mortem|(it|this|the plan) (has )?failed|assume (it|this|i) (failed|get zero)|why (it|this) (would|will|might) fail",
      steps: [
        { type: "say", text: "Imagine it failed. Ask why. Fix that now." },
        ...practice(h, {
          example:
            "My plan: apply to 40 SWE internships with one resume and no referrals.\n" +
            "Assume it's January and I have zero interviews. List the 5 most likely reasons, most likely first, and one fix for each I can do this week.",
          prompt: "My plan: [plan].\nAssume it's [date] and it failed. List the [N] most likely reasons, most likely first, and one fix for each I can do this week.",
          look: ["Reasons are specific to you.", "Each fix fits in a week."]
        })
      ]
    },
    {
      id: s + "/rubric", unit: "prompting", title: "Define good first", xp: 25,
      detect: "rubric|scor(e|ing) (it|yourself|against)|grading criteria",
      steps: [
        { type: "say", text: "Ask for the grading rubric. Then the work." },
        ...practice(h, {
          example:
            "I want a 15-minute chat with an engineer at a company I'd love to intern at. Before writing my cold message, create a 5-point rubric they'd judge it by.\n" +
            "Then write it (under 90 words), score it against the rubric, and revise until every point is 4/5 or higher.",
          prompt: "Before writing [thing], create a [N]-point rubric [reader] would judge it by.\nThen write it, score it, and revise until every point is 4/5 or higher.",
          look: ["The rubric came first.", "It revised, not just scored."]
        })
      ]
    },
    {
      id: s + "/second-opinion", unit: "prompting", title: "Get a second opinion", xp: 25,
      detect: "another (ai|model)|skeptical reviewer",
      steps: [
        { type: "say", text: "Different models, different blind spots." },
        ...practice(h, {
          example:
            "Another AI told me: \"Sophomores can't get SWE internships at big tech companies. Those programs are only for juniors.\"\n" +
            "Be a skeptical reviewer. What's right, what's wrong, what's missing? Name real programs if you know them, and tell me how to confirm.",
          prompt: "Another AI told me:\n\n[paste answer]\n\nBe a skeptical reviewer. What's right, what's wrong, what's missing?",
          look: ["It separated true, false, and unsure.", "It told you how to check."]
        })
      ]
    },
    {
      id: s + "/fresh", unit: "prompting", title: "Fresh chat, same context", xp: 20,
      detect: "handoff|summari[sz]e (this|our) (chat|conversation)",
      steps: [
        { type: "say", text: "Long chats get worse. Restart with a summary." },
        ...practice(h, {
          text: "Use this in a long chat.",
          example: "Summarize this conversation as a handoff for a new chat:\ngoal, decisions made, current state, open questions, next step.\nOne copyable block.",
          prompt: "Summarize this conversation as a handoff for a new chat:\ngoal, decisions made, current state, open questions, next step.\nOne copyable block.",
          look: ["Paste it into a new chat. Keep going there."]
        })
      ]
    }
  ];
}

// Practice blocks every track reuses (each on its own site).
function uploadPractice(h) {
  return practice(h, {
    example:
      "Attached: my resume. Here's a job post:\n" + JOB_POST + "\n\n" +
      "1. List every skill the post asks for.\n" +
      "2. For each: proven, weak, or missing on my resume. Quote my line.\n" +
      "3. One weekend project that closes the biggest gap.",
    prompt: "Attached: [file]. [what to compare it with]\n\n1. [what to pull out]\n2. [how to judge each, quoting the file]\n3. [one concrete next step]",
    look: ["It quoted your resume, not a guess.", "Screenshots work too: ⌘⇧4 on Mac, Win+Shift+S on Windows, then paste.", "Nothing to attach? Paste the text."]
  });
}
function bannerPractice(h) {
  return practice(h, {
    example:
      "Make a LinkedIn banner, 1584×396. Dark navy background, faint code-grid texture.\n" +
      "Left-aligned text: \"Alex Chen · CS '29 · Python · Java · React\".\n" +
      "Smaller line below: \"Open to SWE internships, summer 2027\".\n" +
      "Minimal. No people, no stock photos.",
    prompt: "Make a [what], [size]. [Background and style].\nText: \"[exact words]\".\n[Mood]. No [what to avoid].",
    look: ["Check every word. Image models still misspell.", "Edit by pointing: “bigger text, keep the rest.”"]
  });
}
function searchPractice(h) {
  return practice(h, {
    example:
      "Find 8 SWE internships for summer 2027 that accept sophomores.\n" +
      "For each: company, program, link to the official careers page, application deadline, who's eligible.\n" +
      "Official pages only. If you can't confirm a deadline, write \"not found\".",
    prompt: "Find [N] [things] for [who].\nFor each: [fields], with a link to the official source.\nOfficial sources only. If you can't confirm something, write \"not found\".",
    look: ["Every row links to the company's own site.", "Open two links. Check the deadline yourself.", "“Not found” beats a confident guess."]
  });
}
function researchPractice(h) {
  return practice(h, {
    example:
      "Research the SWE intern interview process at Stripe for summer 2027: rounds, question types, timeline, and what past interns say.\n" +
      "Cite every claim and flag anything older than 2025.\n" +
      "End with a 2-week prep plan for a sophomore who knows Python and basic data structures.",
    prompt: "Research [question].\nCite every claim and flag anything older than [year].\nEnd with [what you'll do with it].",
    look: ["Claims have sources. Click a few.", "Old info is flagged.", "It's slow and limited. Save it for real decisions."]
  });
}
function tutorPractice(h) {
  return practice(h, {
    example:
      "I'm stuck on LeetCode 3, longest substring without repeating characters.\n" +
      "Don't give me code. Ask me one question at a time until I find the approach myself.\n" +
      "When I have it, make me state the time complexity.",
    prompt: "I'm stuck on [problem].\nDon't give me the answer. Ask me one question at a time until I find it myself.\nThen [check that I understand].",
    look: ["It asked. It didn't tell.", "You wrote the code.", "Interviews test exactly this: explaining your approach."]
  });
}
var TUTOR_DETECT = "socratic|don'?t (just )?give (me )?(the )?(code|answers?)|one question at a time|quiz me";

function knowYouCheck(h, where) {
  return practice(h, {
    example: "What do you know about me and how I like answers? 5 bullets.",
    prompt: "What do you know about me and how I like answers? 5 bullets.",
    look: ["It used what you wrote.", "Wrong or missing? Fix it in " + where + "."]
  });
}

function skillPractice(h, look) {
  return practice(h, {
    example:
      "Write a reusable skill as a SKILL.md file.\n" +
      "Name: tailor-resume\n" +
      "Description (one line): when to use it.\n" +
      "Inputs: my resume and one job post.\n" +
      "Steps: list the job's required skills; match each to a line on my resume; rewrite my 3 most relevant bullets; list the gaps.\n" +
      "Rules: never invent experience; ask me for missing numbers.\n" +
      "Output: a match table, 3 bullets, the gaps.",
    prompt: "Write a reusable skill as a SKILL.md file.\nName: [name]\nDescription (one line): when to use it.\nInputs: [what I'll give it].\nSteps: [numbered steps].\nRules: [hard limits].\nOutput: [format].",
    look: look
  });
}

function gmailPractice(h, prefix) {
  return practice(h, {
    example:
      (prefix || "") + "Search my Gmail for messages from recruiters or careers@ addresses in the last 60 days.\n" +
      "Table: company | role | stage | last email date | next step | deadline.\n" +
      "Flag anything that needs a reply this week.",
    prompt: (prefix || "") + "Search my [app] for [what] in the last [time].\nTable: [columns].\nFlag [what needs action].",
    look: ["Each row points to a real email.", "Read before you let it send or change anything."]
  });
}

// The terminal, taught from the page: AI writes the command, you run it, you paste back what happened.
function terminal(s, extra) {
  var h = COACH_SITES[s].host;
  return {
    id: s + "/terminal", unit: "code", title: "Your first terminal command", xp: 30,
    steps: [
      { type: "say", text: "AI writes the command. You run it. You paste back what happened." },
      { type: "contrast", bad: "Run a command you don't understand.", good: "Ask what it does. Run it. Paste the output back." },
      ...practice(h, {
        send: "Send. Read what it does before you run it.",
        example:
          "I'm new to the terminal. Give me one safe command that checks whether Python and Git are installed on my computer.\n" +
          "Before the command, explain in one line what it does and confirm it changes nothing.",
        prompt: "I'm on [Mac / Windows]. Give me one terminal command to [goal].\nBefore the command, explain in one line what it does and whether it changes anything."
      }),
      { type: "terminal", text: "Open the terminal. Paste. Press Return.", cmd: { mac: "python3 --version; git --version", win: "python --version; git --version" } },
      { type: "wait-send", site: h, target: "composer", text: "Copy what it printed. Paste it here. Ask what it means." },
      { type: "notice", items: ["You knew what it did before you ran it.", "Errors are fine. Paste them back: that's the loop.", "Never paste passwords, API keys, or sudo commands you don't understand."] }
    ].concat(extra || [])
  };
}

// A real portfolio site: AI writes it, GitHub hosts it free.
function portfolio(s) {
  var h = COACH_SITES[s].host;
  return {
    id: s + "/portfolio", unit: "code", title: "Ship your portfolio", xp: 40,
    steps: [
      { type: "say", text: "Recruiters click links. Give them one." },
      ...practice(h, {
        send: "Send. Download or copy the file it makes.",
        example:
          "Write a one-page portfolio site as a single index.html file.\n" +
          "Sections: my name, one line about me, 3 projects (title, one line, link), contact.\n" +
          "Clean, fast, readable on phones. No frameworks, no external images.",
        prompt: "Write a [kind of page] as a single index.html file.\nSections: [list].\n[Style]. No frameworks."
      }),
      { type: "goto", site: h, url: "https://github.com/new", text: "Now GitHub. Sign up free if you need to." },
      { type: "spotlight", site: GH, target: { sel: ["#repository-name-input", "input[aria-label='Repository name']", "input[name='repository[name]']"] }, text: "Name it <b>yourusername.github.io</b>" },
      { type: "click", site: GH, target: { text: ["Create repository", "创建仓库"] }, text: "Public. Create." },
      { type: "wait-url", site: GH, url: "github\\.com/[^/]+/[^/?#]+/?$", text: "Creating…" },
      { type: "click", site: GH, target: { text: ["uploading an existing file", "Add file", "添加文件"] }, text: "Upload index.html. Then Commit." },
      { type: "notice", items: ["Live at yourusername.github.io in a minute.", "Put the link on your resume and LinkedIn."] }
    ]
  };
}

// ───────── ChatGPT (UI checked 2026-11-09: English Business UI + Chinese Free UI) ─────────
var G = COACH_SITES.chatgpt.host;
var GPT = {
  avatar: { sel: ["[data-testid='accounts-profile-button']", "button[aria-label='Open profile menu']"], text: ["Open profile menu", "打开个人资料菜单"] },
  personalization: { text: ["Personalization", "个性化"] },
  settings: { text: ["Settings", "设置"] },
  dataControls: { text: ["Data controls", "数据管理", "数据控制"] },
  customInstructions: { text: ["Custom instructions", "自定义指令"], any: true, wrap: "section" },
  memory: { text: ["Enable memory", "启用记忆", "开启记忆", "ChatGPT memory", "ChatGPT 记忆", "记忆"], any: true, wrap: "row" },
  training: { text: ["Improve the model for everyone", "为所有人改进模型"], any: true, wrap: "row" },
  plus: { sel: ["[data-testid='composer-plus-btn']", "button[aria-label='Add files and more']"], text: ["Add files and more", "添加文件等"] },
  addFiles: { text: ["Add photos & files", "Add photos and files", "添加照片和文件", "订阅 Plus，获得更多上传额度"] },
  webSearch: { text: ["Web search", "网页搜索"] },
  deepResearch: { text: ["Deep research", "深度研究"] },
  think: { text: ["Think", "Thinking", "思考", "思考一下"] },
  images: { sel: ["a[href='/images']"], text: ["Images", "图像"] },
  plugins: { sel: ["a[href='/plugins']"], text: ["Plugins", "插件"] },
  newProject: { text: ["New project", "Add new project", "新项目", "新建项目", "添加新项目"] },
  gmail: { text: ["Gmail"] }
};

var CHATGPT = {
  units: units(),
  lessons: [brief("chatgpt")].concat(prompting("chatgpt"), [
    {
      id: "chatgpt/know-you", unit: "setup", title: "Make it know you", xp: 30,
      steps: [
        { type: "say", text: "Tell it once who you are. Every chat gets better." },
        { type: "click", site: G, target: GPT.avatar, text: "Your profile. Bottom left." },
        { type: "click", site: G, target: GPT.personalization, text: "Personalization." },
        { type: "copy", site: G, target: GPT.customInstructions, text: "Custom instructions: click <b>ChatGPT</b>. Paste this, then make it yours.", copy: ABOUT_ME },
        { type: "spotlight", site: G, target: GPT.memory, text: "Memory: it remembers you across chats. Turn it off for anything private." },
        { type: "goto", site: G, url: "https://chatgpt.com/", text: "Try it in a new chat." },
        ...knowYouCheck(G, "Personalization")
      ]
    },
    {
      id: "chatgpt/privacy", unit: "setup", title: "Your data, your call", xp: 20,
      steps: [
        { type: "say", text: "Know what can train the model. Then decide." },
        { type: "click", site: G, target: GPT.avatar, text: "Your profile." },
        { type: "click", site: G, target: GPT.settings, text: "Settings." },
        { type: "click", site: G, target: GPT.dataControls, text: "Data controls." },
        { type: "spotlight", site: G, target: GPT.training, text: "On: your chats can help train models. Your call." },
        { type: "notice", items: ["Turn it off before pasting anything private.", "Temporary chat: not saved, not in memory.", "Settings → Usage shows what's left on your plan."] }
      ]
    },
    {
      id: "chatgpt/upload", unit: "tools", title: "Upload what you see", xp: 25,
      steps: [
        { type: "say", text: "PDFs, screenshots, code, spreadsheets. If you can see it, attach it." },
        { type: "click", site: G, target: GPT.plus, text: "+ next to the chat box." },
        { type: "spotlight", site: G, target: GPT.addFiles, text: "Add photos & files. Attach your resume.", missing: "Out of uploads? Paste the text instead. Next." },
        ...uploadPractice(G)
      ]
    },
    {
      id: "chatgpt/images", unit: "tools", title: "Make images", xp: 25,
      detect: "(make|create|generate) (a|an|me a) [\\w ]{0,30}(image|banner|logo|picture|diagram)",
      steps: [
        { type: "say", text: "Banners, diagrams, photo edits. Describe it like a designer." },
        { type: "click", site: G, target: GPT.images, text: "Images. In the sidebar." },
        ...bannerPractice(G)
      ]
    },
    {
      id: "chatgpt/search", unit: "tools", title: "Search, with sources", xp: 25,
      detect: "official (pages?|sources?) only|link to the (official|source)|cite",
      steps: [
        { type: "say", text: "Anything after its training date needs a search." },
        { type: "click", site: G, target: GPT.plus, text: "Open +." },
        { type: "click", site: G, target: GPT.webSearch, text: "Web search." },
        ...searchPractice(G)
      ]
    },
    {
      id: "chatgpt/deep-research", unit: "tools", title: "Deep research", xp: 30,
      steps: [
        { type: "say", text: "Minutes of reading, one cited report." },
        { type: "click", site: G, target: GPT.plus, text: "Open +." },
        { type: "click", site: G, target: GPT.deepResearch, text: "Deep research." },
        ...researchPractice(G)
      ]
    },
    {
      id: "chatgpt/learn", unit: "tools", title: "Learn it, don't copy it", xp: 25,
      detect: TUTOR_DETECT,
      steps: [
        { type: "say", text: "Hard problem? Make it think. Make it teach." },
        { type: "spotlight", site: G, target: GPT.think, text: "Think: slower, better on hard problems.", missing: "Find Think under +. Next." },
        ...tutorPractice(G)
      ]
    },
    {
      id: "chatgpt/project", unit: "organize", title: "One Project for the search", xp: 30,
      steps: [
        { type: "say", text: "A Project keeps files, instructions and chats together." },
        { type: "click", site: G, target: GPT.newProject, text: "New project. In the sidebar.", missing: "Hover “Projects” in the sidebar, then +." },
        { type: "wait-url", site: G, url: "/project|/g/g-p-", text: "Name it “SWE internship 2027”. Create." },
        { type: "copy", site: G, text: "Add your resume to its files. Paste these as its instructions.", copy: PROJECT_INSTRUCTIONS },
        { type: "notice", items: ["Every chat in it starts knowing all this.", "One Project per goal: a class, the search, a side project."] }
      ]
    },
    {
      id: "chatgpt/skill", unit: "organize", title: "Skills: teach it once", xp: 30,
      detect: "skill\\.md|reusable skill",
      steps: [
        { type: "say", text: "A skill is a saved recipe. It runs whenever the job matches." },
        { type: "contrast", bad: "Re-explaining your resume rules every chat.", good: "One skill, tailor-resume, used every time." },
        { type: "say", text: "School or work plan: profile → Skills. Free: a Project's instructions do the job." },
        ...skillPractice(G, ["The description says when to use it.", "Steps are numbered. Rules are hard limits.", "The same file works as a Claude or Codex skill."])
      ]
    },
    {
      id: "chatgpt/gmail", unit: "connect", title: "Plugins: your Gmail", xp: 35,
      steps: [
        { type: "say", text: "Let it read your email and calendar. Only when you ask." },
        { type: "click", site: G, target: GPT.plugins, text: "Plugins. In the sidebar." },
        { type: "click", site: G, target: GPT.gmail, text: "Gmail. Connect it." },
        { type: "goto", site: G, url: "https://chatgpt.com/", text: "Back to a new chat." },
        ...gmailPractice(G)
      ]
    },
    terminal("chatgpt"),
    {
      id: "chatgpt/codex", unit: "code", title: "Codex in your terminal", xp: 40,
      steps: [
        { type: "say", text: "Codex reads your files and runs commands. You review." },
        { type: "terminal", text: "Install it. Needs Node.js. No Node? Ask ChatGPT how.", cmd: { mac: "npm install -g @openai/codex", win: "npm install -g @openai/codex" } },
        { type: "terminal", text: "Make a folder. Start Codex. Sign in with ChatGPT.", cmd: { mac: "mkdir intern-tracker && cd intern-tracker && codex", win: "mkdir intern-tracker; cd intern-tracker; codex" } },
        { type: "copy", text: "Give it a real task.", copy: "Build a command-line tool in Python that tracks my internship applications in a CSV: add one, list by deadline, update status. Write tests. Explain each file before you create it." },
        { type: "notice", items: ["It asked before running commands.", "You read the changes before accepting.", "Your plan's limits: Settings → Usage."] }
      ]
    },
    portfolio("chatgpt")
  ])
};

// ───────── Claude (UI checked 2026-11-09: settings is a dialog, #settings/… and #customize/…) ─────────
var C = COACH_SITES.claude.host;
var CL = {
  avatar: { sel: ["[data-testid='user-menu-button']"] },
  settings: { sel: ["[data-testid='user-menu-settings']"], text: ["Settings", "设置"] },
  yourClaude: { text: ["Your Claude", "你的 Claude"] },
  instructions: { sel: ["textarea#conversation-preferences", "textarea[placeholder^='e.g. keep']"], text: ["Instructions for Claude", "给 Claude 的指令"], any: true },
  importMemory: { text: ["Import memory from other AI providers", "从其他 AI 导入记忆"], any: true, wrap: "row" },
  privacy: { text: ["Privacy", "隐私"] },
  training: { text: ["Help improve Claude", "帮助改进 Claude"], any: true, wrap: "row" },
  customize: { text: ["Customize", "自定义"] },
  skills: { text: ["Skills", "技能"] },
  connectors: { text: ["Connectors", "连接器"] },
  gmail: { text: ["Gmail"] },
  plus: { sel: ["[data-testid='chat-input-attach']", "button[aria-label^='Add files']", "button[aria-label='Open attachments menu']"] },
  addFiles: { text: ["Add files or photos", "Upload a file", "Add files", "添加文件或照片", "上传文件"] },
  projects: { sel: ["a[href='/projects']"], text: ["Projects", "项目"] },
  newProject: { text: ["New project", "新建项目"] }
};

var CLAUDE = {
  units: units(),
  lessons: [brief("claude")].concat(prompting("claude"), [
    {
      id: "claude/know-you", unit: "setup", title: "Make it know you", xp: 30,
      steps: [
        { type: "say", text: "Tell it once who you are. Every chat gets better." },
        { type: "click", site: C, target: CL.avatar, text: "Your name. Bottom left." },
        { type: "click", site: C, target: CL.settings, text: "Settings." },
        { type: "click", site: C, target: CL.yourClaude, text: "Your Claude." },
        { type: "copy", site: C, target: CL.instructions, text: "Instructions for Claude. Paste this, then make it yours.", copy: ABOUT_ME },
        { type: "spotlight", site: C, target: CL.importMemory, text: "Coming from ChatGPT? Import what it knows.", missing: "Memory lives here too. Next." },
        { type: "goto", site: C, url: "https://claude.ai/new", text: "Try it in a new chat." },
        ...knowYouCheck(C, "Settings → Your Claude")
      ]
    },
    {
      id: "claude/privacy", unit: "setup", title: "Your data, your call", xp: 20,
      steps: [
        { type: "say", text: "Know what can train the model. Then decide." },
        { type: "click", site: C, target: CL.avatar, text: "Your name." },
        { type: "click", site: C, target: CL.settings, text: "Settings." },
        { type: "click", site: C, target: CL.privacy, text: "Privacy." },
        { type: "spotlight", site: C, target: CL.training, text: "On: your chats can help train models. Your call.", missing: "Work and school plans don't train on chats. Next." },
        { type: "notice", items: ["Turn it off before pasting anything private.", "Incognito chat: not saved to history."] }
      ]
    },
    {
      id: "claude/upload", unit: "tools", title: "Upload what you see", xp: 25,
      steps: [
        { type: "say", text: "PDFs, screenshots, code, spreadsheets. If you can see it, attach it." },
        { type: "click", site: C, target: CL.plus, text: "+ next to the chat box." },
        { type: "spotlight", site: C, target: CL.addFiles, text: "Add files. Attach your resume." },
        ...uploadPractice(C)
      ]
    },
    {
      id: "claude/build", unit: "tools", title: "Build, don't chat", xp: 35,
      detect: "(build|make) (me )?(an? )?(interactive|working) ",
      steps: [
        { type: "say", text: "Ask for a working app, not advice about one." },
        ...practice(C, {
          example:
            "Build an interactive internship tracker as an artifact.\n" +
            "Add company, role, status (applied, OA, interview, offer, rejected) and deadline.\n" +
            "Sort by deadline. Show counts by status at the top. Keep my entries when I come back.",
          prompt: "Build an interactive [tool] as an artifact.\n[What I can do in it].\n[How it should look and behave].",
          look: ["It built something you can click.", "Ask for changes in plain words.", "Publish to share the link."]
        })
      ]
    },
    {
      id: "claude/files", unit: "tools", title: "Real files, not text", xp: 25,
      detect: "\\.(docx|xlsx|pptx|pdf)\\b",
      steps: [
        { type: "say", text: "Ask for the file: .docx, .xlsx, .pptx, .pdf." },
        ...practice(C, {
          example:
            "Make my resume a one-page .docx from what I paste below. One column, ATS-friendly: no tables, icons or photos.\n" +
            "Then give me a PDF too.\n\n[paste your resume text]",
          prompt: "Make [what] as a .[docx / xlsx / pptx / pdf] from what I paste below. [Layout rules].\n\n[paste]",
          look: ["You got a file, not a wall of text.", "Open it. Check the layout yourself."]
        })
      ]
    },
    {
      id: "claude/search", unit: "tools", title: "Search, with sources", xp: 25,
      detect: "official (pages?|sources?) only|link to the (official|source)|cite",
      steps: [
        { type: "say", text: "Anything recent needs a search. Ask for links." },
        ...searchPractice(C)
      ]
    },
    {
      id: "claude/learn", unit: "tools", title: "Learn it, don't copy it", xp: 25,
      detect: TUTOR_DETECT,
      steps: [
        { type: "say", text: "Make it teach, not answer." },
        ...tutorPractice(C)
      ]
    },
    {
      id: "claude/project", unit: "organize", title: "One Project for the search", xp: 30,
      steps: [
        { type: "say", text: "A Project keeps files, instructions and chats together." },
        { type: "click", site: C, target: CL.projects, text: "Projects. In the sidebar." },
        { type: "click", site: C, target: CL.newProject, text: "New project." },
        { type: "wait-url", site: C, url: "claude\\.ai/project/", text: "Name it “SWE internship 2027”. Create." },
        { type: "copy", site: C, text: "Add your resume to its files. Paste these as its instructions.", copy: PROJECT_INSTRUCTIONS },
        { type: "notice", items: ["Every chat in it starts knowing all this.", "One Project per goal: a class, the search, a side project."] }
      ]
    },
    {
      id: "claude/skills", unit: "organize", title: "Skills: teach it once", xp: 35,
      detect: "skill\\.md|reusable skill|create a skill",
      steps: [
        { type: "say", text: "A skill is a saved recipe. Claude uses it whenever the job matches." },
        { type: "click", site: C, target: CL.avatar, text: "Your name." },
        { type: "click", site: C, target: CL.settings, text: "Settings." },
        { type: "click", site: C, target: CL.customize, text: "Customize." },
        { type: "click", site: C, target: CL.skills, text: "Skills. Word, Excel, PowerPoint and PDF are built in." },
        { type: "goto", site: C, url: "https://claude.ai/new", text: "Now make your own." },
        ...practice(C, {
          example:
            "Help me create a skill called tailor-resume.\n" +
            "When I give you my resume and a job post: list the job's required skills, match each to a line on my resume, rewrite my 3 most relevant bullets, list the gaps.\n" +
            "Rules: never invent experience; ask me for missing numbers.\n" +
            "Package it so I can upload it in Settings → Customize → Skills.",
          prompt: "Help me create a skill called [name].\nWhen I give you [inputs]: [numbered steps].\nRules: [hard limits].\nPackage it so I can upload it in Settings → Customize → Skills.",
          look: ["Upload it under Skills.", "Next time, just say: tailor my resume to this post."]
        })
      ]
    },
    {
      id: "claude/gmail", unit: "connect", title: "Connectors: your Gmail", xp: 35,
      steps: [
        { type: "say", text: "Let it read your email and calendar. Only when you ask." },
        { type: "click", site: C, target: CL.avatar, text: "Your name." },
        { type: "click", site: C, target: CL.settings, text: "Settings." },
        { type: "click", site: C, target: CL.customize, text: "Customize." },
        { type: "click", site: C, target: CL.connectors, text: "Connectors." },
        { type: "click", site: C, target: CL.gmail, text: "Gmail. Connect it." },
        { type: "goto", site: C, url: "https://claude.ai/new", text: "Back to a new chat." },
        ...gmailPractice(C)
      ]
    },
    terminal("claude"),
    {
      id: "claude/claude-code", unit: "code", title: "Claude Code in your terminal", xp: 40,
      steps: [
        { type: "say", text: "Claude Code reads your files and runs commands. You review." },
        { type: "terminal", text: "Install it. Needs a paid plan or API credits.", cmd: { mac: "curl -fsSL https://claude.ai/install.sh | bash", win: "irm https://claude.ai/install.ps1 | iex" } },
        { type: "terminal", text: "Make a folder. Start Claude Code. Sign in.", cmd: { mac: "mkdir intern-tracker && cd intern-tracker && claude", win: "mkdir intern-tracker; cd intern-tracker; claude" } },
        { type: "copy", text: "Give it a real task.", copy: "Build a command-line tool in Python that tracks my internship applications in a CSV: add one, list by deadline, update status. Write tests. Explain each file before you create it." },
        { type: "notice", items: ["It asked before running commands.", "You read the changes before accepting.", "Your skills work here too."] }
      ]
    },
    portfolio("claude")
  ])
};

// ───────── Grok (logged-out UI checked 2026-11-09) ─────────
var X = COACH_SITES.grok.host;
var GK = {
  attach: { sel: ["[data-testid='attach-button']", "button[aria-label='Attach']"], text: ["Attach", "附件"] },
  imagine: { sel: ["a[href='/imagine']"], text: ["Imagine"] },
  model: { sel: ["button[aria-label^='Model']"], text: ["Auto", "Fast", "Expert"] },
  settings: { sel: ["button[aria-label='Settings']"], text: ["Settings", "设置"] },
  customize: { text: ["Customize", "Customization", "Personalize", "自定义", "个性化"] },
  private: { sel: ["a[href*='private' i]", "button[aria-label*='private' i]"], text: ["Private", "私密"] },
  projects: { sel: ["a[href='/project']", "a[href^='/project']"], text: ["Projects", "项目"] }
};

var GROK = {
  units: units(),
  lessons: [brief("grok")].concat(prompting("grok"), [
    {
      id: "grok/know-you", unit: "setup", title: "Make it know you", xp: 30,
      steps: [
        { type: "say", text: "Tell it once who you are. Every chat gets better." },
        { type: "click", site: X, target: GK.settings, text: "Settings." },
        { type: "click", site: X, target: GK.customize, text: "Customize.", missing: "Sign in first. Then Settings → Customize." },
        { type: "copy", site: X, text: "Paste this as your instructions, then make it yours.", copy: ABOUT_ME },
        { type: "goto", site: X, url: "https://grok.com/", text: "Try it in a new chat." },
        ...knowYouCheck(X, "Settings → Customize")
      ]
    },
    {
      id: "grok/private", unit: "setup", title: "Private when it matters", xp: 15,
      steps: [
        { type: "spotlight", site: X, target: GK.private, text: "Private chat: not saved to your history.", missing: "Look for the ghost icon, top right." },
        { type: "notice", items: ["Use it before pasting anything private.", "Settings → Data controls: what can train the model."] }
      ]
    },
    {
      id: "grok/x-search", unit: "tools", title: "Search X, live", xp: 30,
      detect: "(search|on) x\\b|posts? (on|from) x|twitter",
      steps: [
        { type: "say", text: "Grok reads X in real time. Use it for what people say right now." },
        ...practice(X, {
          example:
            "Search X for posts from the last 30 days about SWE intern interviews at Stripe, Ramp or Databricks.\n" +
            "Quote 6 posts with links and dates.\n" +
            "Then split it: facts (rounds, question types, dates) vs. opinions.",
          prompt: "Search X for posts from the last [time] about [topic].\nQuote [N] posts with links and dates.\nThen split it: facts vs. opinions.",
          look: ["Every quote links to a real post.", "Posts are anecdotes, not policy.", "Check dates. Old threads resurface."]
        })
      ]
    },
    {
      id: "grok/upload", unit: "tools", title: "Upload what you see", xp: 25,
      steps: [
        { type: "say", text: "PDFs, screenshots, code, spreadsheets. If you can see it, attach it." },
        { type: "click", site: X, target: GK.attach, text: "Attach. In the chat box. Pick your resume." },
        ...uploadPractice(X)
      ]
    },
    {
      id: "grok/imagine", unit: "tools", title: "Make images", xp: 25,
      detect: "(make|create|generate) (a|an|me a) [\\w ]{0,30}(image|banner|logo|picture|video)",
      steps: [
        { type: "say", text: "Images, and short videos from them." },
        { type: "click", site: X, target: GK.imagine, text: "Imagine. In the sidebar." },
        ...bannerPractice(X)
      ]
    },
    {
      id: "grok/learn", unit: "tools", title: "Think harder", xp: 25,
      detect: TUTOR_DETECT,
      steps: [
        { type: "spotlight", site: X, target: GK.model, text: "The model picker. Expert thinks longer on hard problems." },
        ...tutorPractice(X)
      ]
    },
    {
      id: "grok/project", unit: "organize", title: "One Project for the search", xp: 30,
      steps: [
        { type: "say", text: "A Project keeps files, instructions and chats together." },
        { type: "click", site: X, target: GK.projects, text: "Projects. In the sidebar.", missing: "Sign in first. Projects is in the sidebar." },
        { type: "copy", site: X, text: "New project. Add your resume. Paste these as its instructions.", copy: PROJECT_INSTRUCTIONS },
        { type: "notice", items: ["Every chat in it starts knowing all this."] }
      ]
    },
    terminal("grok")
  ])
};

// ───────── Gemini (UI checked 2026-11-09: sidebar Images / Scheduled / Customize) ─────────
var M = COACH_SITES.gemini.host;
var GM = {
  settings: { sel: ["button[aria-label='Settings']", "button[aria-label='Settings & help']"], text: ["Settings", "设置"] },
  instructions: { text: ["Personal context", "Instructions for Gemini", "Saved info", "个人情境", "Gemini 使用说明", "已保存的信息"] },
  activity: { text: ["Activity", "Gemini Apps Activity", "Keep Activity", "活动记录", "Gemini 应用活动记录"] },
  temporary: { sel: ["button[aria-label*='temporary chat' i]"], text: ["Temporary chat", "临时对话"] },
  upload: { sel: ["button[aria-label*='upload' i]", "button[aria-label*='Add files' i]", "[data-test-id='upload-menu-button']"], text: ["Add files", "Upload", "上传"] },
  images: { sel: ["a[href='/images']"], text: ["Images", "图片"] },
  tools: { sel: ["button[aria-label*='Tools' i]", "toolbox-drawer button"], text: ["Tools", "工具"] },
  deepResearch: { text: ["Deep Research", "深度研究"] },
  guided: { text: ["Guided Learning", "引导式学习"] },
  customize: { sel: ["a[href='/customize']"], text: ["Customize", "自定义"] },
  skills: { text: ["Skills", "技能"] },
  connectors: { text: ["Connectors", "连接器", "Apps", "应用"] },
  scheduled: { sel: ["a[href='/scheduled']"], text: ["Scheduled", "定时"] }
};

var GEMINI = {
  units: units(),
  lessons: [brief("gemini")].concat(prompting("gemini"), [
    {
      id: "gemini/know-you", unit: "setup", title: "Make it know you", xp: 30,
      steps: [
        { type: "say", text: "Tell it once who you are. Every chat gets better." },
        { type: "click", site: M, target: GM.settings, text: "Settings. Bottom left." },
        { type: "click", site: M, target: GM.instructions, text: "Personal context.", missing: "Look for Personal context or Saved info." },
        { type: "copy", site: M, text: "Add this, then make it yours.", copy: ABOUT_ME },
        { type: "goto", site: M, url: "https://gemini.google.com/app", text: "Try it in a new chat." },
        ...knowYouCheck(M, "Settings")
      ]
    },
    {
      id: "gemini/privacy", unit: "setup", title: "Your data, your call", xp: 20,
      steps: [
        { type: "say", text: "Know what's kept and what can train the model." },
        { type: "click", site: M, target: GM.settings, text: "Settings." },
        { type: "spotlight", site: M, target: GM.activity, text: "Activity: what's saved and reviewed. Your call.", missing: "Look for Activity. Next." },
        { type: "spotlight", site: M, target: GM.temporary, text: "Temporary chat: not saved.", missing: "Temporary chat is next to the chat box. Next." },
        { type: "notice", items: ["Use a temporary chat before pasting anything private."] }
      ]
    },
    {
      id: "gemini/upload", unit: "tools", title: "Upload what you see", xp: 25,
      steps: [
        { type: "say", text: "PDFs, screenshots, code, spreadsheets. If you can see it, attach it." },
        { type: "click", site: M, target: GM.upload, text: "+ in the chat box. Add your resume." },
        ...uploadPractice(M)
      ]
    },
    {
      id: "gemini/images", unit: "tools", title: "Make images", xp: 25,
      detect: "(make|create|generate) (a|an|me a) [\\w ]{0,30}(image|banner|logo|picture|diagram)",
      steps: [
        { type: "say", text: "Banners, diagrams, photo edits. Describe it like a designer." },
        { type: "click", site: M, target: GM.images, text: "Images. In the sidebar." },
        ...bannerPractice(M)
      ]
    },
    {
      id: "gemini/deep-research", unit: "tools", title: "Deep Research", xp: 30,
      steps: [
        { type: "say", text: "Minutes of reading, one cited report." },
        { type: "click", site: M, target: GM.tools, text: "Tools. In the chat box." },
        { type: "click", site: M, target: GM.deepResearch, text: "Deep Research." },
        ...researchPractice(M)
      ]
    },
    {
      id: "gemini/learn", unit: "tools", title: "Learn it, don't copy it", xp: 25,
      detect: TUTOR_DETECT,
      steps: [
        { type: "click", site: M, target: GM.tools, text: "Tools." },
        { type: "click", site: M, target: GM.guided, text: "Guided Learning: it teaches instead of answering.", missing: "Not here? The prompt does the same. Done." },
        ...tutorPractice(M)
      ]
    },
    {
      id: "gemini/skills", unit: "organize", title: "Skills: teach it once", xp: 30,
      detect: "skill\\.md|reusable skill",
      steps: [
        { type: "say", text: "A skill is a saved recipe. It runs whenever the job matches." },
        { type: "click", site: M, target: GM.customize, text: "Customize. In the sidebar." },
        { type: "click", site: M, target: GM.skills, text: "Skills. Browse what's built in." },
        { type: "goto", site: M, url: "https://gemini.google.com/app", text: "Now write your own." },
        ...skillPractice(M, ["The description says when to use it.", "Steps are numbered. Rules are hard limits.", "Same format works in Claude and ChatGPT."])
      ]
    },
    {
      id: "gemini/scheduled", unit: "organize", title: "Runs while you sleep", xp: 35,
      steps: [
        { type: "say", text: "Some jobs repeat. Let it run them." },
        { type: "click", site: M, target: GM.scheduled, text: "Scheduled. In the sidebar.", missing: "Not on your plan yet. The prompt still works. Next." },
        { type: "goto", site: M, url: "https://gemini.google.com/app", text: "Ask it in a new chat." },
        ...practice(M, {
          example: "Every Monday at 8am: find 5 new SWE internships for summer 2027 that accept sophomores. Official links and deadlines only. Skip ones you've shown me before.",
          prompt: "Every [when]: [task]. [Rules]. Skip what you've shown me before.",
          look: ["It confirmed the schedule.", "Check the first run. Then trust it."]
        })
      ]
    },
    {
      id: "gemini/gmail", unit: "connect", title: "Your Gmail, Drive, Calendar", xp: 35,
      steps: [
        { type: "say", text: "It can read your Google apps. Only when you ask." },
        { type: "click", site: M, target: GM.customize, text: "Customize." },
        { type: "click", site: M, target: GM.connectors, text: "Connectors. Turn on Google Workspace." },
        { type: "goto", site: M, url: "https://gemini.google.com/app", text: "Back to a new chat." },
        ...gmailPractice(M, "@Gmail ")
      ]
    },
    terminal("gemini", practice(M, {
      text: "Next: an agent in your terminal. Ask for the official one.",
      example: "What is Google's official AI coding agent for the terminal right now? Is it free with a personal Google account? Give me the install command and link the official docs only.",
      prompt: "What is [company]'s official [tool] right now? Is it free for [my account]? Install command, official docs only.",
      look: ["It linked Google's own docs.", "Read the install page before you run anything."]
    }))
  ])
};

var COACH_TRACKS = { chatgpt: CHATGPT, claude: CLAUDE, grok: GROK, gemini: GEMINI };
function coachTrackOf(lessonId) { return String(lessonId || "").split("/")[0]; }

if (typeof window !== "undefined") {
  window.COACH_SITES = COACH_SITES;
  window.COACH_TRACKS = COACH_TRACKS;
  window.coachTrackOf = coachTrackOf;
}
