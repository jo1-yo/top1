// Curriculum = units → lessons → micro-steps. Pure data: add lessons without touching content.js.
//
// A lesson is a real job, not a prompt experiment:
//   Why     one line                                        (say)
//   See     before → after                                  (contrast)
//   Find    where the feature lives in the real UI          (click / spotlight tours)
//   Do      a filled-in Example that runs as-is, or Yours   (insert: example + prompt template)
//   Look    what a good answer has — the actual learning    (notice)
//   Keep    the template lands in the Kit on completion
//   Own     `detect` (regex) → "mastered" after 3 unprompted uses
//
// Copy rule: one short line per step. Two sentences → two steps.
//
// Step types: say · contrast {bad, good} · goto {url} · spotlight {target} · click {target}
//             insert {example?, prompt} · wait-send · notice {items} · wait-url {url}
// target: "composer" | { sel: [css…] , text: ["Label", "标签"] }  — not found → text + Done
// site:   regex on hostname; elsewhere the coach offers to open it.

var COACH_UNITS = [
  { id: "ask", title: "Ask" },
  { id: "think", title: "Think" },
  { id: "setup", title: "Set up" },
  { id: "connect", title: "Connect" },
  { id: "tools", title: "Tools" },
  { id: "verify", title: "Verify" },
  { id: "ship", title: "Ship" },
  { id: "agents", title: "Agents" },
  { id: "cost", title: "Cost" }
];

var AI_CHAT = "chatgpt\\.com|claude\\.ai|gemini\\.google\\.com";
var GPT = "chatgpt\\.com";
var CLAUDE = "claude\\.ai";
var GH = "github\\.com";

// Real UI hooks (checked on chatgpt.com and claude.ai, 2026-11-09). Labels list English + Chinese UI.
var T = {
  gptAvatar: { sel: ["button[aria-label='Open profile menu']", "[data-testid='accounts-profile-button']"], text: ["Open profile menu", "打开个人资料菜单"] },
  gptPersonalization: { text: ["Personalization", "个性化"] },
  gptSettings: { text: ["Settings", "设置"] },
  gptPlugins: { text: ["Plugins", "插件"] },
  gptScheduled: { text: ["Scheduled", "定时任务", "已安排"] },
  claudeAvatar: { sel: ["[data-testid='user-menu-button']"] },
  claudeSettings: { sel: ["[data-testid='user-menu-settings']"], text: ["Settings", "设置"] },
  claudeCustomize: { text: ["Customize", "自定义"] },
  claudeProjects: { text: ["Projects", "项目"] },
  claudeScheduled: { text: ["Scheduled", "定时"] },
  plus: { sel: ["[data-testid='chat-input-attach']", "form button[aria-label='Add files and more']", "[data-testid='composer-plus-btn']"] }
};

// Do → Look: insert (example + template), send, then what to look for.
function practice(o) {
  var site = o.site || AI_CHAT;
  var steps = [
    { type: "insert", site: site, target: "composer", text: o.text || "Run the example. Or switch to Yours.", example: o.example, prompt: o.prompt },
    { type: "wait-send", site: site, target: "composer", text: o.send || "Send. Then read the answer." }
  ];
  if (o.look) steps.push({ type: "notice", items: o.look });
  return steps;
}

var COACH_LESSONS = [
  // ───────── Ask ─────────
  {
    id: "brief", unit: "ask", title: "Brief, don't ask", xp: 20,
    detect: "(you are|act as)[\\s\\S]{0,400}(goal|context|constraint|output|format)",
    steps: [
      { type: "say", text: "Role. Goal. Context. Constraints. Format." },
      { type: "contrast", bad: "Make my resume better.", good: "You're a recruiter. Rewrite this bullet for a PM internship. 2 lines, one number." },
      ...practice({
        example:
          "You are a senior recruiter at a top tech company.\n" +
          "Goal: rewrite my resume bullet for a PM internship.\n" +
          "Context: I'm a sophomore CS major. My bullet: \"Built a website for my club.\" It now gets 400 visits a month and replaced our Google Form.\n" +
          "Constraints: 2 lines max, start with a verb, one number, no buzzwords.\n" +
          "Output: 3 versions, then pick one and say why.",
        prompt: "You are a [role].\nGoal: [what you want].\nContext: [who you are, what you have].\nConstraints: [length, tone, must / must not].\nOutput: [format].",
        look: ["Every version has a number.", "It picked one and said why.", "Now compare: “make my resume better”."]
      })
    ]
  },
  {
    id: "examples", unit: "ask", title: "Show, don't describe", xp: 20,
    detect: "match the (style|tone|format)|example 1|like this:",
    steps: [
      { type: "say", text: "One example beats ten adjectives." },
      { type: "contrast", bad: "Make it professional but friendly.", good: "Match the tone of this email I liked: …" },
      ...practice({
        example:
          "Write an email to my professor asking for a 2-day extension on Problem Set 4. I had two midterms the same week.\n" +
          "Match the tone of this email I liked:\n\n" +
          "\"Hi Professor Lee, thanks for the clear feedback on my lab report. I fixed the error analysis and attached the new version. Have a great weekend, Maya\"\n\n" +
          "First say in one line what makes that tone work. Then write mine in under 90 words.",
        prompt: "Write [what].\nMatch the style of this example:\n\n[paste an example you like]\n\nFirst say what makes it work. Then write.",
        look: ["It named the tone before writing.", "Same length and warmth as the example."]
      })
    ]
  },
  {
    id: "interview", unit: "ask", title: "Let it ask you", xp: 20,
    detect: "interview me|ask me (\\d+|a few|some)? ?questions|one question at a time",
    steps: [
      { type: "say", text: "Not sure what matters? Let the AI ask." },
      ...practice({
        example:
          "I'm a sophomore choosing between a summer internship, a research position, and building my own project.\n" +
          "Interview me first: one question at a time, max 5. Then recommend one, and say what would change your mind.",
        prompt: "I'm trying to [decide / do something].\nInterview me first: one question at a time, max 5. Then recommend.",
        send: "Send. Answer its questions.",
        look: ["One question at a time.", "The advice uses your answers, not generic tips."]
      })
    ]
  },
  {
    id: "debug", unit: "ask", title: "Debug your homework", xp: 25,
    detect: "(point to|find) the (bug|error)|buggy line|hint before",
    steps: [
      { type: "say", text: "Get the bug found. Keep the learning yours." },
      { type: "contrast", bad: "Fix my code.", good: "Point to the buggy line. Explain why. Hint before the fix." },
      ...practice({
        example:
          "I'm learning Python. This should return the average of a list, but average([2, 4, 6]) returns 3.33 instead of 4.0.\n" +
          "Don't rewrite it. Point to the buggy line, explain why in one sentence, and give me a hint before the fix.\n\n" +
          "def average(nums):\n    total = 0\n    for i in range(1, len(nums)):\n        total += nums[i]\n    return total / len(nums)",
        prompt:
          "I'm learning [language]. This should [expected result], but [what happens instead].\n" +
          "Don't rewrite it. Point to the buggy line, explain why in one sentence, and give me a hint before the fix.\n\n[paste code]",
        look: ["It named the exact line.", "Why came before the fix.", "Ask “why” until you could explain it to a friend."]
      })
    ]
  },

  // ───────── Think ─────────
  {
    id: "expert", unit: "think", title: "Think like an expert", xp: 25,
    detect: "(steelman|attack|argue against|critique) (each|it|them|this)",
    steps: [
      { type: "say", text: "Ask for options. Then make it argue." },
      ...practice({
        example:
          "Act as a top 1% growth marketer. Problem: our university coding club has 40 members and wants 200 by next semester. Budget: $0.\n" +
          "1) Give 3 genuinely different approaches. 2) Attack each one. 3) Pick one and give me a 7-day plan.",
        prompt: "Act as a top 1% [expert]. Problem: [problem].\n1) 3 different approaches. 2) Attack each. 3) Pick one, 7-day plan.",
        look: ["The approaches are actually different.", "It argued against its own ideas."]
      })
    ]
  },
  {
    id: "premortem", unit: "think", title: "Pre-mortem", xp: 25,
    detect: "pre-?mortem|(it|this|the plan) (has )?failed|why (it|this) (would|will|might) fail",
    steps: [
      { type: "say", text: "Imagine it already failed. Ask why." },
      ...practice({
        example:
          "My plan: study for the MCAT 2 hours every night after my part-time job, for 4 months.\n" +
          "It's 4 months later and the plan failed. Write the most likely story of why.\nThen the 3 cheapest ways to prevent it.",
        prompt: "My plan: [plan].\nIt's [time] later and it failed. Write the most likely story of why.\nThen the 3 cheapest ways to prevent it.",
        look: ["The failure story is specific, not generic.", "The fixes cost little and start this week."]
      })
    ]
  },
  {
    id: "tutor", unit: "think", title: "Tutor, not answer key", xp: 25,
    detect: "socratic|don'?t (just )?give (me )?(the )?answers?|quiz me|test me",
    steps: [
      { type: "say", text: "Learning? Make it teach, not tell." },
      { type: "contrast", bad: "Solve this problem.", good: "Don't solve it. Ask me questions until I can." },
      ...practice({
        example:
          "Be my Socratic tutor for the chain rule in calculus.\n" +
          "Don't give answers. One question at a time. Check my reasoning. Hint when I'm stuck.\nEnd with 3 practice problems.",
        prompt: "Be my Socratic tutor for [topic].\nDon't give answers. One question at a time. Check my reasoning. Hint when I'm stuck.\nEnd with 3 practice problems.",
        send: "Send. Then answer it.",
        look: ["It waited for your answer.", "It never handed you the solution."]
      })
    ]
  },
  {
    id: "rubric", unit: "think", title: "Define good first", xp: 25,
    detect: "rubric|scor(e|ing) (it|yourself|against)|grading criteria",
    steps: [
      { type: "say", text: "Set the bar before it writes." },
      ...practice({
        example:
          "Before writing my cover letter for a product design internship at Figma, create a 5-point rubric a hiring manager would use.\n" +
          "Then write it, score it against the rubric, and revise until every point is 4/5 or higher.",
        prompt: "Before writing [thing], create a 5-point rubric [the reader] would use.\nThen write it, score it, and revise until every point is 4/5+.",
        look: ["Rubric first, draft second.", "Scores went up between drafts."]
      })
    ]
  },

  // ───────── Set up: where things live ─────────
  {
    id: "gpt-personal", unit: "setup", title: "Make ChatGPT know you", xp: 30,
    steps: [
      { type: "say", text: "What makes AI yours lives behind your profile picture." },
      { type: "goto", site: GPT, url: "https://chatgpt.com/", text: "In ChatGPT." },
      { type: "click", site: GPT, target: T.gptAvatar, text: "Your profile picture. Bottom left." },
      { type: "click", site: GPT, target: T.gptPersonalization, text: "Personalization." },
      { type: "notice", text: "Two things live here", items: ["Custom instructions: who you are, how to answer.", "Memory: what it keeps between chats."] }
    ]
  },
  {
    id: "about-me", unit: "setup", title: "Write yourself down once", xp: 30,
    steps: [
      { type: "say", text: "One paragraph about you. Every chat starts smarter." },
      ...practice({
        example:
          "Interview me (max 8 questions, one at a time) to write my custom instructions:\n" +
          "who I am, what I'm working on, how I like answers, what to avoid.\nThen output one copyable block under 200 words.",
        prompt:
          "Interview me (max 8 questions, one at a time) to write my custom instructions:\n" +
          "who I am, what I'm working on, how I like answers, what to avoid.\nThen output one copyable block under 200 words.",
        send: "Send. Answer its questions.",
        look: ["Paste the block into Personalization → Custom instructions."]
      })
    ]
  },
  {
    id: "project", unit: "setup", title: "A Project per class", xp: 30,
    steps: [
      { type: "say", text: "Syllabus, notes, instructions. Remembered in every chat." },
      { type: "goto", site: CLAUDE, url: "https://claude.ai/projects", text: "In Claude." },
      { type: "click", site: CLAUDE, target: { text: ["New project", "新建项目"] }, text: "New project." },
      { type: "wait-url", site: CLAUDE, url: "claude\\.ai/project/", text: "Name it after one class." },
      { type: "notice", text: "Then add", items: ["Files: syllabus, slides, your notes.", "Instructions: “Explain with examples. Quiz me at the end.”"] }
    ]
  },
  {
    id: "fresh", unit: "setup", title: "Fresh chat, same context", xp: 25,
    detect: "handoff|summari[sz]e (this|our) (chat|conversation)",
    steps: [
      { type: "say", text: "Long chats get worse. Restart with a summary." },
      ...practice({
        text: "Use this in a long chat.",
        example: "Summarize this conversation as a handoff for a new chat:\ngoal, decisions made, current state, open questions, next step.\nOne copyable block.",
        prompt: "Summarize this conversation as a handoff for a new chat:\ngoal, decisions made, current state, open questions, next step.\nOne copyable block.",
        look: ["Paste it into a new chat. Keep going there."]
      })
    ]
  },

  // ───────── Connect: AI + your stuff ─────────
  {
    id: "gpt-connect", unit: "connect", title: "Connectors in ChatGPT", xp: 35,
    steps: [
      { type: "say", text: "Let AI read your Drive, Calendar, Gmail. Only when you ask." },
      { type: "goto", site: GPT, url: "https://chatgpt.com/", text: "In ChatGPT." },
      { type: "click", site: GPT, target: T.gptPlugins, text: "Plugins. In the sidebar." },
      { type: "click", site: GPT, target: { text: ["Google Drive"] }, text: "Google Drive." },
      { type: "notice", text: "Then", items: ["Connect, and sign in with Google.", "Same place for Gmail and Calendar."] }
    ]
  },
  {
    id: "claude-connect", unit: "connect", title: "Connectors in Claude", xp: 35,
    steps: [
      { type: "say", text: "Same idea in Claude." },
      { type: "goto", site: CLAUDE, url: "https://claude.ai/new", text: "In Claude." },
      { type: "click", site: CLAUDE, target: T.claudeAvatar, text: "Your name. Bottom left." },
      { type: "click", site: CLAUDE, target: T.claudeSettings, text: "Settings." },
      { type: "click", site: CLAUDE, target: T.claudeCustomize, text: "Customize." },
      { type: "click", site: CLAUDE, target: { text: ["Connectors", "连接器"] }, text: "Connectors." },
      { type: "notice", text: "Then", items: ["Google Drive → Connect.", "In a chat, + turns each one on or off."] }
    ]
  },
  {
    id: "ask-your-stuff", unit: "connect", title: "Ask your own files", xp: 30,
    detect: "(in|from|search) my (google )?(drive|docs|calendar|gmail|notion)",
    steps: [
      { type: "say", text: "Connected? Now ask about your own stuff." },
      ...practice({
        example:
          "Search my Google Drive for my most recent resume.\n" +
          "Compare it to this role: Product Design Intern, focused on prototyping and user research.\n" +
          "List 3 gaps and rewrite my top 3 bullets to close them. Name the file you used.",
        prompt: "Search my Google Drive for [file].\n[What to do with it]. Name the file you used.",
        look: ["It named the file it read.", "The gaps are about you, not generic advice."]
      })
    ]
  },
  {
    id: "calendar", unit: "connect", title: "Plan from your calendar", xp: 30,
    detect: "my (google )?calendar",
    steps: [
      ...practice({
        example:
          "Look at my Google Calendar for the next 7 days.\n" +
          "Find 5 free 90-minute blocks for studying, before 10pm.\nShow a table: day, time, what to study.",
        prompt: "Look at my Google Calendar for [period].\nFind [what].\nShow a table.",
        look: ["Blocks avoid your real events.", "Nothing changed in your calendar without asking."]
      })
    ]
  },

  // ───────── Tools: beyond the text box ─────────
  {
    id: "plus", unit: "tools", title: "Everything behind +", xp: 25,
    steps: [
      { type: "say", text: "Most people never open the + menu." },
      { type: "click", site: AI_CHAT, target: T.plus, text: "Open +. Next to the chat box." },
      { type: "notice", text: "In there", items: ["Files: PDFs, slides, spreadsheets.", "Research and web search.", "Your connectors, on or off per chat."] }
    ]
  },
  {
    id: "files", unit: "tools", title: "Quiz me on my slides", xp: 25,
    detect: "(from|on) (my|these|the) (slides|notes|lecture|pdf)",
    steps: [
      { type: "say", text: "Show it, don't describe it." },
      { type: "click", site: AI_CHAT, target: T.plus, text: "Attach your lecture slides (PDF)." },
      ...practice({
        example: "Make a 10-question quiz from these slides: 6 multiple choice, 4 short answer.\nAsk one at a time. Grade each answer and explain mistakes.",
        prompt: "From [these slides / this file], [what you want].\nAsk one at a time. Grade each answer.",
        send: "Send. Take the quiz.",
        look: ["Questions come from your slides, not the internet.", "Wrong answers get an explanation."]
      })
    ]
  },
  {
    id: "research", unit: "tools", title: "Research, then check", xp: 30,
    detect: "separate facts from|flag anything older",
    steps: [
      { type: "say", text: "Big question? Turn on Research in +. Then verify." },
      ...practice({
        example:
          "Research the job market for UX design interns in the US this year.\n" +
          "1-page brief with sources. Separate facts from your guesses. Flag anything older than 12 months.",
        prompt: "Research [question].\n1-page brief with sources. Separate facts from guesses. Flag anything older than 12 months.",
        look: ["Every claim has a source.", "Facts and guesses are labeled."]
      })
    ]
  },
  {
    id: "build", unit: "tools", title: "Build, don't chat", xp: 30,
    detect: "build (me )?(an? )?(interactive|app|tool|tracker|calculator|game)",
    steps: [
      { type: "say", text: "Ask for a tool, not an answer." },
      { type: "contrast", bad: "Explain these notes.", good: "Build me a flashcard app from these notes." },
      ...practice({
        example:
          "Build me an interactive flashcard app from these notes:\n" +
          "Mitochondria: makes ATP through cellular respiration.\nRibosome: builds proteins from mRNA.\n" +
          "Golgi apparatus: packages and ships proteins.\nLysosome: breaks down waste.\n" +
          "Flip on click. Shuffle. Track which ones I miss.",
        prompt: "Build me an interactive [app] from:\n[your material]\n[How it should work].",
        look: ["You got an app, not a paragraph.", "Claude calls it an Artifact. ChatGPT, Canvas."]
      })
    ]
  },

  // ───────── Verify ─────────
  {
    id: "cite", unit: "verify", title: "Make it cite", xp: 25,
    detect: "(source|cite|citation)s?[\\s\\S]{0,80}(confidence|check|verify)|say .?not sure",
    steps: [
      { type: "say", text: "Confident isn't correct." },
      ...practice({
        example:
          "When was the first iPhone released, what did it cost, and how many sold in its first year?\n" +
          "Then list every factual claim you made, with a source I can check and your confidence: high, medium or low.",
        prompt: "[Question].\nThen list every factual claim, with a source I can check and your confidence: high, medium or low.",
        look: ["Open two sources. Do they say that?"]
      })
    ]
  },
  {
    id: "second-opinion", unit: "verify", title: "Get a second opinion", xp: 25,
    detect: "another (ai|model)|skeptical reviewer",
    steps: [
      { type: "say", text: "Different models, different blind spots." },
      ...practice({
        example:
          "Another AI told me: \"Pluto was reclassified as a dwarf planet in 2006 because it is smaller than our Moon.\"\n" +
          "Be a skeptical reviewer. What's right, what's wrong, what's missing?",
        prompt: "Another AI told me:\n\n[paste answer]\n\nBe a skeptical reviewer. What's right, what's wrong, what's missing?",
        look: ["It kept the true fact and fixed the wrong reason."]
      })
    ]
  },
  {
    id: "integrity", unit: "verify", title: "What not to outsource", xp: 20,
    steps: [
      { type: "say", text: "If AI does the thinking, you don't learn it." },
      { type: "contrast", bad: "Write my essay.", good: "Critique my draft. Quiz me. Explain what I got wrong." },
      { type: "say", text: "Check each class's AI policy. Unsure? Disclose." }
    ]
  },

  // ───────── Ship ─────────
  {
    id: "gh-repo", unit: "ship", title: "Your first repo", xp: 30,
    steps: [
      { type: "say", text: "A folder in the cloud, with history." },
      { type: "goto", site: GH, url: "https://github.com/new", text: "GitHub. Sign up free." },
      { type: "spotlight", site: GH, target: { sel: ["#repository-name-input", "input[aria-label='Repository name']", "input[name='repository[name]']"] }, text: "Name: <b>username.github.io</b>" },
      { type: "click", site: GH, target: { text: ["Create repository", "创建仓库"] }, text: "Public. Add README. Create." },
      { type: "wait-url", site: GH, url: "github\\.com/[^/]+/[^/?#]+/?$", text: "Creating…" }
    ]
  },
  {
    id: "gh-site", unit: "ship", title: "Ship a website", xp: 40,
    steps: [
      { type: "goto", site: AI_CHAT, url: "https://chatgpt.com/", text: "Let AI write it." },
      ...practice({
        example:
          "Write one self-contained index.html (inline CSS) for my personal site.\n" +
          "Me: Maya Chen, CS + Design at NYU. Projects: a campus food-waste tracker, a typeface for my club. Links: github.com/mayachen, mayachen@nyu.edu.\n" +
          "Style: minimal, lots of whitespace, mobile-first. Code only.",
        prompt: "Write one self-contained index.html (inline CSS) for my personal site.\nMe: [name, school, projects, links].\nStyle: [minimal, mobile-first]. Code only.",
        send: "Send. Save the code as index.html."
      }),
      { type: "click", site: GH, target: { text: ["Add file", "添加文件"] }, text: "In your repo: Add file → Upload → Commit." },
      { type: "say", site: GH, text: "Live at username.github.io in a minute." }
    ]
  },
  {
    id: "claude-code", unit: "ship", title: "AI that edits files", xp: 30,
    steps: [
      { type: "say", text: "Claude Code works in your folders. Reads, writes, runs, pushes." },
      { type: "goto", url: "https://claude.com/claude-code", text: "Install it. Then improve your site with it." }
    ]
  },

  // ───────── Agents ─────────
  {
    id: "agent-loop", unit: "agents", title: "Your first agent", xp: 40,
    detect: "agent loop|done when:",
    steps: [
      { type: "say", text: "Plan. Do. Check. Repeat." },
      ...practice({
        example:
          "Run as an agent loop.\nGoal: find 10 startups in NYC hiring design interns, and draft cold emails to the top 3.\n" +
          "Done when: a table of 10 with why-fit, plus 3 emails under 120 words.\n" +
          "Each turn: show the plan as checkboxes → do the next step → check against done → wait for \"continue\".\n" +
          "Mark anything you can't verify as UNVERIFIED.",
        prompt: "Run as an agent loop.\nGoal: [goal].\nDone when: [finish line].\nEach turn: plan as checkboxes → do next step → check vs. done → wait for \"continue\".",
        send: "Send. Reply “continue” a few times.",
        look: ["Checkboxes tick off turn by turn.", "It stopped to wait for you.", "Unverified things are labeled."]
      })
    ]
  },
  {
    id: "schedule", unit: "agents", title: "Runs while you sleep", xp: 40,
    steps: [
      { type: "say", text: "A task that runs on a schedule. Both ChatGPT and Claude have one." },
      { type: "click", site: AI_CHAT, target: { text: ["Scheduled", "定时任务", "已安排"] }, text: "Scheduled. In the sidebar." },
      { type: "notice", text: "Try", items: ["Sundays 8pm: next week's deadlines from Calendar + Drive.", "Weekdays 8am: 3 new internships matching my resume."] }
    ]
  },
  {
    id: "workflow", unit: "agents", title: "Save what worked", xp: 30,
    detect: "reusable (workflow|prompt|template)",
    steps: [
      { type: "say", text: "A great chat, made repeatable." },
      ...practice({
        text: "Use this after a chat that went well.",
        example: "Turn this conversation into a reusable workflow:\nname · inputs as [brackets] · the exact prompt · a quality checklist.\nOne copyable block.",
        prompt: "Turn this conversation into a reusable workflow:\nname · inputs as [brackets] · the exact prompt · a quality checklist.\nOne copyable block.",
        look: ["Keep it as Project instructions or a Claude Skill."]
      })
    ]
  },
  {
    id: "parallel", unit: "agents", title: "Manage, don't chat", xp: 35,
    detect: "parallel agents?|one of \\d+ (parallel )?agents",
    steps: [
      { type: "say", text: "Top users run several AIs at once. They review; they don't wait." },
      ...practice({
        text: "Paste into 3 tabs, one task each.",
        example:
          "You're one of 3 parallel agents. Your task only: research 5 competitors of Notion for students.\n" +
          "Work until done. Then a 5-line summary and what you need from me.",
        prompt: "You're one of 3 parallel agents. Your task only: [task].\nWork until done. Then a 5-line summary and what you need from me.",
        look: ["Check back in 10 minutes. Review, don't babysit."]
      })
    ]
  },

  // ───────── Cost ─────────
  {
    id: "cheap", unit: "cost", title: "Draft cheap, check smart", xp: 25,
    detect: "(smaller|cheaper|another) model wrote",
    steps: [
      { type: "say", text: "Free model drafts. Premium model reviews." },
      ...practice({
        example:
          "A smaller model wrote this. Don't rewrite it.\n3 weakest points, one line each, then minimal edits.\n\n" +
          "\"Social media has both positive and negative effects on teenagers. On one hand it helps them connect. On the other hand it can be addictive. In conclusion, balance is important.\"",
        prompt: "A smaller model wrote this. Don't rewrite it.\n3 weakest points, one line each, then minimal edits.\n\n[draft]",
        look: ["It kept your draft and fixed only what matters."]
      })
    ]
  },
  {
    id: "right-model", unit: "cost", title: "Right model, right job", xp: 20,
    steps: [
      { type: "say", text: "Fast model: rewrites, summaries, quick questions." },
      { type: "say", text: "Thinking model: math, code, plans, hard calls." },
      { type: "say", text: "Next task: pick the model on purpose." }
    ]
  }
];

if (typeof window !== "undefined") { window.COACH_LESSONS = COACH_LESSONS; window.COACH_UNITS = COACH_UNITS; }
