// Top1 Coach — in-page onboarding overlay that works on top of other people's products
// (ChatGPT, Claude, Gemini, GitHub, and the local demo page).
// Everything lives in a Shadow DOM so the host site's CSS can't break it and vice versa.
(function () {
  if (window.__top1CoachLoaded) return;
  window.__top1CoachLoaded = true;

  var LESSONS = window.COACH_LESSONS || [];
  var UNITS = window.COACH_UNITS || [];
  var hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  var IS_DEMO = location.protocol === "file:" || /^(localhost|127\.0\.0\.1)$/.test(location.hostname);

  // ---------- storage (chrome.storage in the extension, localStorage on the demo page) ----------
  var store = {
    get: function (cb) {
      if (hasChrome) chrome.storage.local.get(["top1"], function (r) { cb(r.top1 || {}); });
      else { try { cb(JSON.parse(localStorage.getItem("top1") || "{}")); } catch (e) { cb({}); } }
    },
    set: function (v) {
      if (hasChrome) chrome.storage.local.set({ top1: v });
      else { try { localStorage.setItem("top1", JSON.stringify(v)); } catch (e) {} }
    }
  };

  var state = { lesson: 0, step: 0, xp: 0, streak: 0, lastDay: null, done: [], open: true, pending: null };

  // ---------- finding things on someone else's page ----------
  // The chat box. Order matters: stable per-site hooks first.
  // ChatGPT also renders editable ProseMirror "writing blocks" INSIDE replies — those must never win,
  // so ChatGPT's box is only accepted inside its <form>.
  var COMPOSER_SELECTORS = [
    "[data-testid='chat-input']",                    // Claude
    "form div.ProseMirror[contenteditable='true']",  // ChatGPT (2026)
    "form #prompt-textarea",                         // older ChatGPT
    "rich-textarea .ql-editor",                      // Gemini
    "[data-coach='composer']"                        // local demo
  ];
  // Anything inside a rendered message is content, not the chat box.
  var IN_MESSAGE = "article,[data-message-author-role],[data-message-id],[data-testid^='conversation-turn'],.font-claude-message,message-content";
  var CLICKABLE = "a,button,[role=button],[role=tab],[role=menuitem],[role=link],summary,label,input[type=submit]";

  function visible(el) {
    if (!el || el.closest("#top1-coach-host")) return false;
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
  }
  function bySelectors(list) {
    for (var i = 0; i < list.length; i++) {
      var els = document.querySelectorAll(list[i]);
      for (var j = 0; j < els.length; j++) if (visible(els[j])) return els[j];
    }
    return null;
  }
  // Labels often carry icon-font glyphs (private-use chars, e.g. Claude's sidebar) or emoji → strip them.
  function norm(s) {
    return (s || "").replace(/[\uE000-\uF8FF\u200B-\u200D\uFEFF]/g, "").replace(/\s+/g, " ").trim()
      .replace(/^[^\p{L}\p{N}]+/u, "").toLowerCase();
  }
  // Match by what the user sees: exact label first, then "starts with" (labels often carry icons/shortcuts).
  // `text` may be a list (UI languages: ["Settings", "设置"]). Visible text and aria-label are both checked.
  function byText(text) {
    var wants = [].concat(text).map(norm), starts = null;
    var els = document.querySelectorAll(CLICKABLE);
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var labels = [el.innerText, el.value, el.getAttribute("aria-label")].map(norm).filter(Boolean);
      if (!labels.length || !visible(el)) continue;
      for (var w = 0; w < wants.length; w++) {
        for (var l = 0; l < labels.length; l++) {
          if (labels[l] === wants[w]) return el;
          if (!starts && labels[l].indexOf(wants[w]) === 0 && labels[l].length < wants[w].length + 40) starts = el;
        }
      }
    }
    return starts;
  }
  function findComposer() {
    var hit = bySelectors(COMPOSER_SELECTORS);
    if (hit) return hit;
    // Unknown layout: the lowest visible editor that is not inside a message.
    var best = null, bestBottom = -1;
    var els = document.querySelectorAll("textarea,[contenteditable='true']");
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (!visible(el) || el.closest(IN_MESSAGE)) continue;
      var b = el.getBoundingClientRect().bottom;
      if (b > bestBottom) { best = el; bestBottom = b; }
    }
    return best;
  }
  function resolve(target) {
    if (!target) return null;
    if (target === "composer") return findComposer();
    return (target.sel && bySelectors(target.sel)) || (target.text && byText(target.text)) || null;
  }

  function composerText(el) { return el ? (el.value !== undefined ? el.value : el.innerText || "") : ""; }
  function insertIntoComposer(text) {
    var el = findComposer();
    if (!el) return false;
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      // React-controlled inputs need the native setter + an input event.
      var setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value").set;
      setter.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      // ProseMirror / Quill editors respect execCommand insertText (keeps their internal state in sync).
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);
    }
    return true;
  }
  function onSite(step) { return IS_DEMO || !step.site || new RegExp(step.site).test(location.hostname); }

  // ---------- UI ----------
  var host = document.createElement("div");
  host.id = "top1-coach-host";
  host.style.cssText = "all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;";
  document.documentElement.appendChild(host);
  var root = host.attachShadow({ mode: "open" });

  root.innerHTML =
    "<style>" +
    ":host{all:initial}" +
    // Apple-ish tokens: frosted glass, system type, hairlines, one ink color.
    ".w{--glass:rgba(255,255,255,.72);--fg:#1d1d1f;--fg2:#6e6e73;--line:rgba(0,0,0,.08);--well:rgba(0,0,0,.045);--pri:#1d1d1f;--on-pri:#fff;--accent:#0071e3;--hi:rgba(255,255,255,.75);--seg:#fff}" +
    "@media (prefers-color-scheme:dark){.w{--glass:rgba(36,36,40,.52);--fg:#f5f5f7;--fg2:#a1a1a6;--line:rgba(255,255,255,.1);--well:rgba(255,255,255,.07);--pri:#f5f5f7;--on-pri:#1d1d1f;--accent:#0a84ff;--hi:rgba(255,255,255,.14);--seg:rgba(255,255,255,.16)}}" +
    "*{box-sizing:border-box;margin:0;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Helvetica Neue',sans-serif;-webkit-font-smoothing:antialiased;letter-spacing:-.01em}" +
    ".glass{background:var(--glass);-webkit-backdrop-filter:blur(40px) saturate(180%);backdrop-filter:blur(40px) saturate(180%);box-shadow:0 0 0 .5px var(--line),inset 0 .5px 0 var(--hi),0 24px 60px -16px rgba(0,0,0,.28)}" +
    ".spot{position:fixed;z-index:1;border-radius:14px;pointer-events:none;display:none;transition:all .35s cubic-bezier(.2,.8,.2,1);" +
    "box-shadow:0 0 0 9999px rgba(0,0,0,.22),0 0 0 1.5px rgba(255,255,255,.95),0 0 28px 6px rgba(255,255,255,.28)}" +
    ".spot.on{display:block;animation:breathe 2.4s ease-in-out infinite}" +
    "@keyframes breathe{50%{box-shadow:0 0 0 9999px rgba(0,0,0,.22),0 0 0 1.5px rgba(255,255,255,.95),0 0 36px 10px rgba(255,255,255,.18)}}" +
    ".card{position:fixed;z-index:2;transition:top .35s cubic-bezier(.2,.8,.2,1),bottom .35s cubic-bezier(.2,.8,.2,1);right:24px;bottom:24px;width:300px;max-width:calc(100vw - 32px);color:var(--fg);border-radius:22px;pointer-events:auto;overflow:hidden;animation:in .4s cubic-bezier(.2,.8,.2,1)}" +
    "@keyframes in{from{opacity:0;transform:translateY(8px) scale(.98)}}" +
    ".bar{height:2px;background:var(--line)}" +
    ".bar i{display:block;height:100%;background:var(--accent);transition:width .5s cubic-bezier(.2,.8,.2,1)}" +
    ".head{display:flex;align-items:center;gap:6px;padding:14px 18px 0}" +
    ".cap{font-size:11px;font-weight:500;color:var(--fg2)}" +
    ".grow{flex:1}" +
    ".x{cursor:pointer;border:none;background:none;color:var(--fg2);font-size:15px;line-height:1;padding:2px 0 2px 8px;opacity:.7}" +
    ".x:hover{opacity:1}" +
    ".body{padding:6px 18px 18px}" +
    "h3{font-size:17px;font-weight:600;line-height:1.3;margin-bottom:4px}" +
    "p{font-size:14px;line-height:1.45;color:var(--fg2);margin-bottom:16px}" +
    "p b{color:var(--fg);font-weight:600}" +
    "pre{white-space:pre-wrap;font:12px/1.5 ui-monospace,'SF Mono',Menlo,monospace;color:var(--fg);background:var(--well);border-radius:12px;padding:10px 12px;margin:-4px 0 16px;max-height:132px;overflow:auto}" +
    ".row{display:flex;justify-content:flex-end;align-items:center;gap:4px}" +
    "button.b{cursor:pointer;border:none;border-radius:999px;padding:8px 16px;font-size:13px;font-weight:600;background:var(--pri);color:var(--on-pri);transition:transform .15s,opacity .15s}" +
    "button.b:hover{opacity:.88}button.b:active{transform:scale(.96)}" +
    "button.g{background:none;color:var(--fg2);font-weight:500;padding:8px 10px}" +
    "button.g:hover{color:var(--fg);opacity:1}" +
    ".bubble{position:fixed;z-index:2;right:24px;bottom:24px;width:44px;height:44px;border-radius:50%;display:none;align-items:center;justify-content:center;cursor:pointer;pointer-events:auto}" +
    ".bubble svg{width:18px;height:18px;color:var(--fg)}" +
    ".hint{font-size:12px;margin:-8px 0 16px}" +
    ".check{width:36px;height:36px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;margin:4px 0 12px}" +
    ".seg{display:inline-flex;padding:2px;border-radius:9px;background:var(--well);margin:-6px 0 10px}" +
    ".seg button{border:none;background:none;font-family:inherit;font-size:12px;font-weight:500;color:var(--fg2);padding:5px 12px;border-radius:7px;cursor:pointer}" +
    ".seg button.on{background:var(--seg);color:var(--fg);box-shadow:0 1px 2px rgba(0,0,0,.08),0 0 0 .5px var(--line)}" +
    ".look{list-style:none;padding:0;margin:-6px 0 16px;display:grid;gap:9px}" +
    ".look li{position:relative;padding-left:20px;font-size:14px;line-height:1.4;color:var(--fg)}" +
    ".look li::before{content:'';position:absolute;left:1px;top:5px;width:9px;height:9px;border-radius:50%;box-shadow:inset 0 0 0 1.25px var(--fg2)}" +
    ".vs{display:grid;gap:6px;margin:-4px 0 16px}" +
    ".vs div{display:flex;gap:8px;font-size:13px;line-height:1.4;padding:9px 12px;border-radius:12px;background:var(--well)}" +
    ".vs i{font-style:normal;font-size:11px;line-height:18px;flex:none;width:12px;text-align:center}" +
    ".vs .bad{color:var(--fg2)}.vs .bad i{color:#ff453a}.vs .good i{color:#30d158}" +
    ".nudge{position:fixed;right:24px;bottom:80px;max-width:320px;display:none;align-items:center;gap:8px;padding:6px 6px 6px 16px;border-radius:999px;pointer-events:auto;color:var(--fg);font-size:13px;z-index:3}" +
    ".nudge.on{display:flex;animation:in .4s cubic-bezier(.2,.8,.2,1)}" +
    ".nudge span{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
    ".nudge button.b{padding:6px 12px;font-size:12px}" +
    "@media (max-width:700px){.nudge{left:12px;right:12px;bottom:72px;max-width:none}}" +
    "@media (max-width:700px){.card{top:12px;bottom:auto;right:12px;left:12px;width:auto}pre{max-height:88px}}" +
    "@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}" +
    "</style>" +
    "<div class='w'>" +
    "<div class='spot'></div>" +
    "<div class='card glass'>" +
    "  <div class='bar'><i id='prog'></i></div>" +
    "  <div class='head'><span class='cap' id='unit'></span><span class='grow'></span><span class='cap' id='meta'></span><button class='x' id='min' title='Hide (Alt+Shift+K)'>×</button></div>" +
    "  <div class='body' id='body'></div>" +
    "</div>" +
    "<div class='bubble glass' id='bubble' title='Top1'><svg viewBox='0 0 96 96'><circle cx='31' cy='31' r='13' fill='currentColor'/><path d='M33 75 L68 24' stroke='currentColor' stroke-width='13' stroke-linecap='round'/></svg></div>" +
    "<div class='nudge glass' id='nudge'><span id='nmsg'></span><button class='b' id='nact'></button><button class='x' id='nx'>×</button></div>" +
    "</div>";

  var $ = function (id) { return root.getElementById(id); };
  var spot = root.querySelector(".spot");
  var card = root.querySelector(".card");

  // ---------- spotlight: re-resolve the target (SPAs re-render), reposition every frame ----------
  var spotFor = null;   // target spec for the current step
  var spotEl = null;    // resolved element
  function trackSpot() {
    if (spotEl && state.open && spotEl.isConnected) {
      var r = spotEl.getBoundingClientRect(), pad = 6;
      spot.style.left = r.left - pad + "px";
      spot.style.top = r.top - pad + "px";
      spot.style.width = r.width + pad * 2 + "px";
      spot.style.height = r.height + pad * 2 + "px";
      spot.classList.add("on");
      // Never cover the thing we're pointing at: test against the card's default slot
      // (so it doesn't flip-flop); on overlap, float the card just above the target (or below).
      var ch = card.offsetHeight || 260, narrow = innerWidth <= 700, slot;
      if (narrow) slot = { l: 0, t: 12, rt: innerWidth, b: 12 + ch };
      else slot = { l: innerWidth - 24 - card.offsetWidth, t: innerHeight - 24 - ch, rt: innerWidth, b: innerHeight };
      var hit = r.left < slot.rt && r.right > slot.l && r.top < slot.b && r.bottom > slot.t;
      if (!hit) { card.style.top = ""; card.style.bottom = ""; }
      else if (r.top > ch + 40) { card.style.top = "auto"; card.style.bottom = (innerHeight - r.top + 16) + "px"; }
      else { card.style.bottom = "auto"; card.style.top = (r.bottom + 16) + "px"; }
    } else { spot.classList.remove("on"); card.style.top = ""; card.style.bottom = ""; }
    requestAnimationFrame(trackSpot);
  }
  requestAnimationFrame(trackSpot);
  setInterval(function () {
    if (!host.isConnected) document.documentElement.appendChild(host); // aggressive re-renders
    if (spotFor && (!spotEl || !spotEl.isConnected || !visible(spotEl))) {
      var was = !!spotEl;
      spotEl = resolve(spotFor);
      if (!!spotEl !== was) renderHint();
    }
  }, 500);

  // ---------- step watchers ----------
  var watch = null;
  function stopWatch() { if (watch) clearInterval(watch); watch = null; }
  function watchForSend() {
    var hadText = composerText(findComposer()).trim().length > 15;
    watch = setInterval(function () {
      var len = composerText(findComposer()).trim().length;
      if (len > 15) hadText = true;
      else if (hadText && len === 0) { stopWatch(); next(); } // composer emptied after having a prompt → sent
    }, 400);
  }
  function watchForUrl(pattern) {
    var re = new RegExp(pattern);
    var check = function () { if (re.test(location.href)) { stopWatch(); next(); } };
    watch = setInterval(check, 500);
  }
  // "click" steps: advance when the user clicks the highlighted element.
  document.addEventListener("click", function (e) {
    var S = curStep();
    if (!S || S.type !== "click" || !spotEl) return;
    if (spotEl === e.target || spotEl.contains(e.target)) setTimeout(next, 150);
  }, true);

  // ---------- render ----------
  function save() { store.set(state); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function curLesson() { return LESSONS[state.lesson]; }
  function curStep() { var L = curLesson(); return L && L.steps[state.step]; }
  function unitOf(L) { for (var i = 0; i < UNITS.length; i++) if (UNITS[i].id === L.unit) return UNITS[i]; return { emoji: "", title: "" }; }
  function hostLabel(re) {
    if (!re) return "another site";
    if (/github/.test(re)) return "GitHub";
    if (/chatgpt|claude|gemini/.test(re) && /\|/.test(re)) return "your AI chat";
    if (/claude/.test(re)) return "Claude";
    if (/chatgpt/.test(re)) return "ChatGPT";
    return "another site";
  }

  function render() {
    card.style.display = state.open ? "block" : "none";
    $("bubble").style.display = state.open ? "none" : "flex";
    renderMeta();
    spotFor = null; spotEl = null;
    stopWatch();

    var L = curLesson();
    if (!L) return renderAllDone();
    var S = L.steps[state.step];
    var U = unitOf(L);
    $("unit").textContent = U.title + " · " + (state.lesson + 1) + "/" + LESSONS.length;
    $("prog").style.width = Math.round((state.step / L.steps.length) * 100) + "%";

    var html = "<h3>" + L.title + "</h3>";
    var buttons = "";

    if (!onSite(S)) {
      // user is on the wrong site for this step → offer to take them there
      var url = S.url || siteHome(S.site);
      html += "<p>Continues on " + hostLabel(S.site) + ".</p>";
      buttons = "<button class='b g' id='skip'>Skip</button><button class='b' id='go'>Open</button>";
      $("body").innerHTML = html + "<div class='row'>" + buttons + "</div>";
      bind("go", function () { location.href = url; });
      bind("skip", next);
      return;
    }

    var label = S.text || (S.type === "notice" ? "Look for" : "");
    html += (label ? "<p>" + label + "</p>" : "") + "<div id='hint'></div>";
    var shown = null;

    if (S.type === "contrast") {
      html += "<div class='vs'><div class='bad'><i>✕</i>" + escapeHtml(S.bad) + "</div><div class='good'><i>✓</i>" + escapeHtml(S.good) + "</div></div>";
      buttons = (state.step > 0 ? "<button class='b g' id='back'>Back</button>" : "") + "<button class='b' id='next'>Next</button>";
    } else if (S.type === "goto") {
      buttons = "<button class='b g' id='next'>Skip</button><button class='b' id='go'>Open</button>";
    } else if (S.type === "spotlight") {
      spotFor = S.target;
      buttons = "<button class='b' id='next'>Next</button>";
    } else if (S.type === "click") {
      spotFor = S.target;
      buttons = "<button class='b g' id='back'>Back</button><button class='b g' id='next'>Done</button>";
    } else if (S.type === "insert") {
      spotFor = "composer";
      // A filled-in example runs as-is (see a real result first); "Yours" is the reusable template.
      var exMode = !!S.example && !showYours;
      shown = exMode ? S.example : S.prompt;
      if (S.example) html += "<div class='seg'><button id='mEx' class='" + (exMode ? "on" : "") + "'>Example</button><button id='mYo' class='" + (exMode ? "" : "on") + "'>Yours</button></div>";
      html += "<pre>" + escapeHtml(shown) + "</pre>";
      buttons = "<button class='b g' id='copy'>Copy</button><button class='b' id='ins'>Insert</button>";
    } else if (S.type === "wait-send") {
      spotFor = "composer";
      buttons = "<button class='b g' id='back'>Back</button><button class='b' id='next'>Sent</button>";
      watchForSend();
    } else if (S.type === "notice") {
      html += "<ul class='look'>" + S.items.map(function (i) { return "<li>" + i + "</li>"; }).join("") + "</ul>";
      buttons = "<button class='b g' id='back'>Back</button><button class='b' id='next'>Got it</button>";
    } else if (S.type === "wait-url") {
      buttons = "<button class='b g' id='next'>Done</button>";
      watchForUrl(S.url);
    } else {
      buttons = (state.step > 0 ? "<button class='b g' id='back'>Back</button>" : "") + "<button class='b' id='next'>Next</button>";
    }
    $("body").innerHTML = html + "<div class='row'>" + buttons + "</div>";
    if (spotFor) spotEl = resolve(spotFor);
    renderHint();

    bind("next", next);
    bind("back", back);
    bind("go", function () {
      // last step points off-platform (e.g. docs) → open it in a new tab and finish the lesson
      if (state.step === L.steps.length - 1) { window.open(S.url, "_blank"); return next(); }
      // advance first so the next page opens on the following step
      state.step++; save();
      if (/^https?:/.test(S.url) && new URL(S.url).origin === location.origin && S.url.indexOf("#") > -1 && location.pathname === new URL(S.url).pathname) {
        location.hash = new URL(S.url).hash; render();
      } else location.href = S.url;
    });
    bind("mEx", function () { showYours = false; render(); });
    bind("mYo", function () { showYours = true; render(); });
    bind("copy", function () { navigator.clipboard && navigator.clipboard.writeText(shown); this.textContent = "Copied"; });
    bind("ins", function () {
      if (insertIntoComposer(shown)) { coachedPrompt = shown; next(); }
      else { navigator.clipboard && navigator.clipboard.writeText(shown); this.textContent = "Copied"; }
    });
  }

  // When a target can't be found, say so instead of silently pointing at nothing.
  function renderHint() {
    var h = $("hint");
    if (!h) return;
    h.innerHTML = spotFor && !spotEl ? "<p class='hint'>Not found here. Tap Done when finished.</p>" : "";
  }

  function siteHome(re) {
    if (!re) return location.href;
    if (/github/.test(re)) return "https://github.com/";
    if (/claude/.test(re) && !/chatgpt/.test(re)) return "https://claude.ai/new";
    return "https://chatgpt.com/";
  }

  function renderAllDone() {
    $("unit").textContent = "";
    $("prog").style.width = "100%";
    $("body").innerHTML =
      "<div class='check'>✓</div><h3>All done.</h3><p>New lessons weekly.</p>" +
      "<div class='row'><button class='b g' id='reset'>Restart</button><button class='b' id='hide'>Close</button></div>";
    bind("reset", function () { state.lesson = 0; state.step = 0; save(); render(); });
    bind("hide", toggle);
  }

  function lessonCelebrate(L) {
    stopWatch();
    spotFor = null; spotEl = null;
    $("prog").style.width = "100%";
    $("body").innerHTML =
      "<div class='check'>✓</div><h3>" + L.title + "</h3><p>+" + L.xp + " XP" + (firstPrompt(L) ? " · Saved to Kit" : "") + "</p>" +
      "<div class='row'><button class='b g' id='later'>Later</button><button class='b' id='go'>Continue</button></div>";
    bind("go", function () { render(); });
    bind("later", function () { render(); toggle(); });
  }

  function renderMeta() { $("meta").textContent = (state.streak ? "Day " + state.streak + " · " : "") + state.xp + " XP"; }
  function bind(id, fn) { var el = $(id); if (el) el.addEventListener("click", fn); }
  function escapeHtml(s) { return s.replace(/[&<>]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]; }); }

  var showYours = false;
  function next() {
    showYours = false;
    var L = curLesson();
    if (!L) return;
    if (state.step < L.steps.length - 1) { state.step++; save(); return render(); }
    // lesson complete → XP + streak
    if (state.done.indexOf(L.id) === -1) { state.done.push(L.id); state.xp += L.xp; }
    addToKit(L);
    var t = today();
    if (state.lastDay !== t) {
      var y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
      state.streak = state.lastDay === y ? state.streak + 1 : 1;
      state.lastDay = t;
    }
    state.lesson++; state.step = 0; save();
    renderMeta();
    lessonCelebrate(L);
  }
  function back() { showYours = false; if (state.step > 0) { state.step--; save(); render(); } }
  function toggle() { state.open = !state.open; save(); render(); }
  function startLesson(id) {
    var i = LESSONS.findIndex(function (l) { return l.id === id; });
    if (i >= 0) { state.lesson = i; state.step = 0; state.open = true; save(); render(); }
  }

  // ---------- Kit: every finished lesson leaves a reusable prompt behind ----------
  function firstPrompt(L) {
    for (var i = 0; i < L.steps.length; i++) if (L.steps[i].type === "insert") return L.steps[i].prompt;
    return null;
  }
  function addToKit(L) {
    var p = firstPrompt(L);
    if (!p) return;
    state.kit = state.kit || [];
    if (!state.kit.some(function (k) { return k.id === L.id; })) state.kit.push({ id: L.id, title: L.title, prompt: p });
  }

  // ---------- Own it: watch the user's OWN prompts (locally — text never leaves this page) ----------
  // A skill is "mastered" when the user does it 3× without the coach. That's the real learning metric.
  // Nudges: at most one tip per 10 min, only while the coach is tucked away, and they can be turned off.
  var AI_HOST = IS_DEMO || /(^|\.)(chatgpt\.com|claude\.ai|gemini\.google\.com)$/.test(location.hostname);
  var coachedPrompt = null, lastText = "", armedAt = 0, pageSends = 0;
  var HANDOFF = "Summarize this conversation as a handoff for a new chat:\ngoal, decisions made, current state, open questions, next step.\nOne copyable block.";
  var BRIEF_IT = "Before you answer, ask me 3 quick questions so my last message becomes a real brief: goal, context, format.";

  function arm() { armedAt = Date.now(); var t = composerText(findComposer()).trim(); if (t) lastText = t; }
  if (AI_HOST) {
    document.addEventListener("keydown", function (e) {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
      var c = findComposer();
      if (c && (c === e.target || c.contains(e.target))) arm();
    }, true);
    document.addEventListener("click", function (e) {
      var b = e.target.closest && e.target.closest("button");
      if (b && /send/i.test((b.getAttribute("aria-label") || "") + (b.getAttribute("data-testid") || ""))) arm();
    }, true);
    setInterval(function () {
      var t = composerText(findComposer()).trim();
      if (t) { lastText = t; return; }
      if (lastText && armedAt && Date.now() - armedAt < 2500) { var sent = lastText; lastText = ""; armedAt = 0; onSend(sent); }
      else lastText = ""; // cleared by hand, not sent
    }, 300);
  }

  function onSend(text) {
    pageSends++;
    // the coach wrote this one → not the user's own skill
    if (coachedPrompt && text.slice(0, 10) === coachedPrompt.slice(0, 10)) { coachedPrompt = null; return; }
    var S = curStep();
    if (S && (S.type === "wait-send" || S.type === "insert")) return;

    state.uses = state.uses || {};
    state.mastered = state.mastered || [];
    var newly = null;
    LESSONS.forEach(function (L) {
      if (!L.detect || !new RegExp(L.detect, "i").test(text)) return;
      state.uses[L.id] = (state.uses[L.id] || 0) + 1;
      if (state.uses[L.id] >= 3 && state.mastered.indexOf(L.id) < 0) { state.mastered.push(L.id); newly = L; }
    });
    save();
    if (newly) return nudge("Mastered · " + newly.title, null);
    if (text.length < 40 && text.indexOf("\n") < 0) nudge("Short prompt.", { label: "Brief it", prompt: BRIEF_IT });
    else if (pageSends === 20) nudge("Long chat.", { label: "Hand off", prompt: HANDOFF });
  }

  var nudgeTimer = null;
  function nudge(msg, action) {
    if (action) {
      if (state.nudges === false) return;
      if (state.open && curLesson()) return;                       // coach is already talking
      if (Date.now() - (state.lastNudge || 0) < 10 * 60e3) return;  // calm by default
      state.lastNudge = Date.now(); save();
    }
    var n = $("nudge");
    n.style.top = state.open ? "24px" : ""; n.style.bottom = state.open ? "auto" : "";
    $("nmsg").textContent = msg;
    $("nact").style.display = action ? "" : "none";
    if (action) {
      $("nact").textContent = action.label;
      $("nact").onclick = function () { insertIntoComposer(action.prompt); hideNudge(); };
    }
    n.classList.add("on");
    clearTimeout(nudgeTimer);
    nudgeTimer = setTimeout(hideNudge, 12000);
  }
  function hideNudge() { $("nudge").classList.remove("on"); }
  $("nx").addEventListener("click", hideNudge);

  $("min").addEventListener("click", toggle);
  $("bubble").addEventListener("click", toggle);
  document.addEventListener("keydown", function (e) {
    if (e.altKey && e.shiftKey && (e.key === "K" || e.key === "k" || e.code === "KeyK")) toggle();
  });

  // Messages from popup / background (start a lesson, toggle).
  if (hasChrome && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
      if (msg.type === "start") { startLesson(msg.lessonId); sendResponse({ ok: true }); }
      if (msg.type === "toggle") toggle();
      if (msg.type === "insert") sendResponse({ ok: insertIntoComposer(msg.prompt) });
    });
  }
  // Progress made in another tab (e.g. finished a step on GitHub) → follow along here.
  if (hasChrome && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (c) {
      var nv = c.top1 && c.top1.newValue;
      if (!nv) return;
      if (nv.pending) { state = nv; var p = state.pending; state.pending = null; startLesson(p); return; }
      if (nv.lesson !== state.lesson || nv.step !== state.step || nv.open !== state.open) { state = nv; render(); }
      else state = nv;
    });
  }

  store.get(function (saved) {
    for (var k in saved) state[k] = saved[k];
    if (state.pending) { var p = state.pending; state.pending = null; startLesson(p); }
    else render();
  });

  // expose for the demo page / debugging
  window.top1Coach = {
    start: startLesson, toggle: toggle, root: root,
    state: function () { return state; },
    resolve: resolve, nudge: nudge
  };
})();
