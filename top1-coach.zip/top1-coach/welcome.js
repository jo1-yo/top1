// Pick your AI → its track's first lesson opens there.
document.querySelectorAll("button[data-site]").forEach(function (b) {
  b.onclick = function () { startLesson(COACH_TRACKS[b.dataset.site].lessons[0].id, true); };
});
