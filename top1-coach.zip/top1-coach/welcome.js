    document.querySelectorAll("button[data-site]").forEach(function (b) {
      b.onclick = function () {
        var site = b.dataset.site;
        chrome.storage.local.get(["top1"], function (r) {
          var s = r.top1 || {}; s.site = site;
          chrome.storage.local.set({ top1: s }, function () { startLesson(COACH_LESSONS[0].id, site); });
        });
      };
    });
