// Popup: Path (lesson map, done / mastered) · Kit (prompts saved from finished lessons) · tips switch.
var S = {}, tab = "path";

function load(cb) { chrome.storage.local.get(["top1"], function (r) { S = r.top1 || {}; cb && cb(); }); }
function save() { chrome.storage.local.set({ top1: S }); }

function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

function render() {
  document.getElementById("meta").textContent = (S.streak ? "Day " + S.streak + " · " : "") + (S.xp || 0) + " XP";
  document.querySelectorAll(".seg button").forEach(function (b) { b.classList.toggle("on", b.dataset.tab === tab); });
  document.getElementById("tips").classList.toggle("on", S.nudges !== false);
  var ul = document.getElementById("list");
  ul.innerHTML = "";
  (tab === "path" ? renderPath : renderKit)(ul);
}

function renderPath(ul) {
  var done = S.done || [], own = S.mastered || [];
  COACH_UNITS.forEach(function (U) {
    var lessons = COACH_LESSONS.filter(function (L) { return L.unit === U.id; });
    var owned = lessons.filter(function (L) { return own.indexOf(L.id) >= 0; }).length;
    ul.appendChild(el("li", "unit", U.title + (owned ? " · " + owned + " mastered" : "")));
    var box = el("li", "card");
    lessons.forEach(function (L) {
      var i = COACH_LESSONS.indexOf(L);
      var cls = "l" + (done.indexOf(L.id) >= 0 ? " ok" : "") + (own.indexOf(L.id) >= 0 ? " own" : "") + (i === (S.lesson || 0) ? " cur" : "");
      var row = el("div", cls);
      row.appendChild(el("span", "dot"));
      row.appendChild(el("span", "t", L.title));
      row.appendChild(el("span", "xp", own.indexOf(L.id) >= 0 ? "Mastered" : String(L.xp)));
      row.onclick = function () { startLesson(L.id, null, function () { window.close(); }); };
      box.appendChild(row);
    });
    ul.appendChild(box);
  });
}

function renderKit(ul) {
  var kit = S.kit || [];
  if (!kit.length) { ul.appendChild(el("li", "empty", "Finish a lesson. Its prompt lands here.")); return; }
  var box = el("li", "card");
  kit.forEach(function (k) {
    var row = el("div", "l");
    row.appendChild(el("span", "t", k.title));
    var hint = el("span", "xp", "Insert");
    row.appendChild(hint);
    row.onclick = function () {
      // Into the current AI chat if we can; otherwise to the clipboard.
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var copy = function () { navigator.clipboard.writeText(k.prompt).then(function () { hint.textContent = "Copied"; }); };
        if (!tabs[0]) return copy();
        chrome.tabs.sendMessage(tabs[0].id, { type: "insert", prompt: k.prompt }, function (res) {
          if (chrome.runtime.lastError || !res || !res.ok) return copy();
          window.close();
        });
      });
    };
    box.appendChild(row);
  });
  ul.appendChild(box);
}

document.querySelectorAll(".seg button").forEach(function (b) { b.onclick = function () { tab = b.dataset.tab; render(); }; });
document.getElementById("tips").onclick = function () { load(function () { S.nudges = S.nudges === false; save(); render(); }); };
load(render);
