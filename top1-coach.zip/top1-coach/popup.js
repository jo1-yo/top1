// Popup: progress at a glance (ring + continue), the path as one row per unit, and the Kit.
var S = {}, tab = "path", openUnit = null;

function load(cb) { chrome.storage.local.get(["top1"], function (r) { S = r.top1 || {}; cb && cb(); }); }
function save() { chrome.storage.local.set({ top1: S }); }
function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
function has(list, id) { return (list || []).indexOf(id) >= 0; }

function render() {
  var done = S.done || [], own = S.mastered || [], total = COACH_LESSONS.length;
  var cur = COACH_LESSONS[S.lesson || 0];

  document.getElementById("meta").textContent = S.streak ? "Day " + S.streak : "";
  // ring: share of lessons done
  var r = 24, c = 2 * Math.PI * r, f = total ? done.length / total : 0;
  var ring = document.getElementById("ring");
  ring.setAttribute("stroke-dasharray", c.toFixed(1));
  ring.setAttribute("stroke-dashoffset", (c * (1 - f)).toFixed(1));
  ring.style.opacity = f ? 1 : 0;
  document.getElementById("done").innerHTML = done.length + " <span>of " + total + "</span>";
  var sub = document.getElementById("sub");
  sub.textContent = "lessons done";
  if (own.length) { sub.appendChild(document.createTextNode(" · ")); sub.appendChild(el("b", null, own.length + " mastered")); }

  // continue
  document.getElementById("clbl").textContent = cur ? (done.length ? "Continue" : "Start") + " · " + unitOf(cur).title : "All done";
  document.getElementById("ctitle").textContent = cur ? cur.title : "Restart any lesson below";
  document.getElementById("cont").onclick = function () { if (cur) startLesson(cur.id, null, function () { window.close(); }); };

  document.querySelectorAll(".seg button").forEach(function (b) { b.classList.toggle("on", b.dataset.tab === tab); });
  document.getElementById("tips").classList.toggle("on", S.nudges !== false);
  var list = document.getElementById("list");
  list.innerHTML = "";
  (tab === "path" ? renderPath : renderKit)(list);
}

function unitOf(L) { for (var i = 0; i < COACH_UNITS.length; i++) if (COACH_UNITS[i].id === L.unit) return COACH_UNITS[i]; return { title: "" }; }

function renderPath(list) {
  var cur = COACH_LESSONS[S.lesson || 0];
  if (openUnit === null) openUnit = cur ? cur.unit : COACH_UNITS[0].id;   // current unit starts open
  COACH_UNITS.forEach(function (U) {
    var lessons = COACH_LESSONS.filter(function (L) { return L.unit === U.id; });
    var nDone = lessons.filter(function (L) { return has(S.done, L.id); }).length;
    var row = el("button", "u" + (openUnit === U.id ? " open" : ""));
    row.appendChild(el("span", "name", U.title));
    var dots = el("span", "dots");
    lessons.forEach(function (L) {
      dots.appendChild(el("i", has(S.mastered, L.id) ? "m" : has(S.done, L.id) ? "d" : L === cur ? "c" : ""));
    });
    row.appendChild(dots);
    row.appendChild(el("span", "n", nDone + "/" + lessons.length));
    row.appendChild(el("span", "chev", "›"));
    row.onclick = function () { openUnit = openUnit === U.id ? "" : U.id; render(); };
    list.appendChild(row);
    if (openUnit !== U.id) return;
    var box = el("div", "lessons");
    lessons.forEach(function (L) {
      var m = has(S.mastered, L.id), d = has(S.done, L.id);
      var l = el("div", "l" + (m ? " m" : d ? " d" : "") + (L === cur ? " c" : ""));
      l.appendChild(el("span", "t", L.title));
      l.appendChild(el("span", "x", m ? "Mastered" : d ? "Done" : L.xp + " XP"));
      l.onclick = function () { startLesson(L.id, null, function () { window.close(); }); };
      box.appendChild(l);
    });
    list.appendChild(box);
  });
}

function renderKit(list) {
  var kit = S.kit || [];
  if (!kit.length) { list.appendChild(el("div", "empty", "Finish a lesson. Its prompt lands here.")); return; }
  kit.forEach(function (k) {
    var row = el("div", "k");
    row.appendChild(el("span", "t", k.title));
    var hint = el("span", "x", "Insert");
    row.appendChild(hint);
    row.onclick = function () {
      // Into the current AI chat if the coach is there; otherwise to the clipboard.
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var copy = function () { navigator.clipboard.writeText(k.prompt).then(function () { hint.textContent = "Copied"; }); };
        if (!tabs[0]) return copy();
        chrome.tabs.sendMessage(tabs[0].id, { type: "insert", prompt: k.prompt }, function (res) {
          if (chrome.runtime.lastError || !res || !res.ok) return copy();
          window.close();
        });
      });
    };
    list.appendChild(row);
  });
}

document.querySelectorAll(".seg button").forEach(function (b) { b.onclick = function () { tab = b.dataset.tab; render(); }; });
document.getElementById("tips").onclick = function () { load(function () { S.nudges = S.nudges === false; save(); render(); }); };
load(render);
