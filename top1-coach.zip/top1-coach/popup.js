// Popup: progress for one AI at a time (the tab you're on, or the last one you used): ring + Continue,
// the path as one row per unit, and the Kit. A switcher picks another AI's path.
var S = {}, tab = "path", openUnit = null, TRACK = "chatgpt";

function load(cb) { chrome.storage.local.get(["top1"], function (r) { S = r.top1 || {}; cb && cb(); }); }
function save() { chrome.storage.local.set({ top1: S }); }
function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
function has(list, id) { return (list || []).indexOf(id) >= 0; }
function track() { return COACH_TRACKS[TRACK]; }
function unitOf(L) { var u = track().units; for (var i = 0; i < u.length; i++) if (u[i].id === L.unit) return u[i]; return { title: "" }; }
function optional(L) { return !!unitOf(L).optional; }
function current() { var p = (S.pos || {})[TRACK] || { lesson: 0 }; return track().lessons[p.lesson]; }
function close() { window.close(); }

// Which AI is this tab? Its content script answers; anywhere else, keep the last one used.
function detect(cb) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (!tabs[0]) return cb();
    chrome.tabs.sendMessage(tabs[0].id, { type: "hello" }, function (res) {
      if (!chrome.runtime.lastError && res && res.track && COACH_TRACKS[res.track]) TRACK = res.track;
      cb();
    });
  });
}

function render() {
  var lessons = track().lessons, core = lessons.filter(function (L) { return !optional(L); });
  var done = core.filter(function (L) { return has(S.done, L.id); }).length;
  var own = lessons.filter(function (L) { return has(S.mastered, L.id); }).length;
  var cur = current();

  document.getElementById("site").value = TRACK;
  document.getElementById("meta").textContent = S.streak ? "Day " + S.streak : "";
  // ring: share of this AI's core lessons done
  var r = 24, c = 2 * Math.PI * r, f = core.length ? done / core.length : 0;
  var ring = document.getElementById("ring");
  ring.setAttribute("stroke-dasharray", c.toFixed(1));
  ring.setAttribute("stroke-dashoffset", (c * (1 - f)).toFixed(1));
  ring.style.opacity = f ? 1 : 0;
  document.getElementById("done").innerHTML = done + " <span>of " + core.length + "</span>";
  var sub = document.getElementById("sub");
  sub.textContent = "lessons done";
  if (own) { sub.appendChild(document.createTextNode(" · ")); sub.appendChild(el("b", null, own + " mastered")); }

  // continue
  var started = lessons.some(function (L) { return has(S.done, L.id); });
  document.getElementById("clbl").textContent = cur ? (started ? "Continue" : "Start") + " · " + unitOf(cur).title : "All done";
  document.getElementById("ctitle").textContent = cur ? cur.title : "Restart any lesson below";
  document.getElementById("cont").onclick = function () { if (cur) startLesson(cur.id, false, close); };

  document.querySelectorAll(".seg button").forEach(function (b) { b.classList.toggle("on", b.dataset.tab === tab); });
  document.getElementById("tips").classList.toggle("on", S.nudges !== false);
  var list = document.getElementById("list");
  list.innerHTML = "";
  (tab === "path" ? renderPath : renderKit)(list);
}

function renderPath(list) {
  var cur = current(), units = track().units;
  if (openUnit === null) openUnit = cur ? cur.unit : units[0].id;   // current unit starts open
  units.forEach(function (U) {
    var lessons = track().lessons.filter(function (L) { return L.unit === U.id; });
    if (!lessons.length) return;
    var nDone = lessons.filter(function (L) { return has(S.done, L.id); }).length;
    var row = el("button", "u" + (openUnit === U.id ? " open" : "") + (U.optional ? " opt" : ""));
    var name = el("span", "name", U.title);
    row.appendChild(name);
    var dots = el("span", "dots");
    lessons.forEach(function (L) {
      dots.appendChild(el("i", has(S.mastered, L.id) ? "m" : has(S.done, L.id) ? "d" : L === cur ? "c" : ""));
    });
    row.appendChild(dots);
    row.appendChild(el("span", "n", U.optional && !nDone ? "Optional" : nDone + "/" + lessons.length));
    row.appendChild(el("span", "chev", "›"));
    row.onclick = function () { openUnit = openUnit === U.id ? "" : U.id; render(); };
    list.appendChild(row);
    if (openUnit !== U.id) return;
    var box = el("div", "lessons");
    lessons.forEach(function (L) {
      var m = has(S.mastered, L.id), d = has(S.done, L.id);
      var l = el("div", "l" + (m ? " m" : d ? " d" : "") + (L === cur ? " c" : ""));
      l.appendChild(el("span", "t", L.title));
      l.appendChild(el("span", "x", m ? "Mastered" : d ? "Done" : L.xp + " XP"));
      l.onclick = function () { startLesson(L.id, false, close); };
      box.appendChild(l);
    });
    list.appendChild(box);
  });
}

function renderKit(list) {
  var kit = S.kit || [];
  if (!kit.length) { list.appendChild(el("div", "empty", "Finish a lesson. Its prompt lands here.")); return; }
  kit.forEach(function (k) {
    var row = el("div", "k");
    row.appendChild(el("span", "t", k.title));
    var hint = el("span", "x", "Insert");
    row.appendChild(hint);
    row.onclick = function () {
      // Into the current AI chat if the coach is there; otherwise to the clipboard.
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var copy = function () { navigator.clipboard.writeText(k.prompt).then(function () { hint.textContent = "Copied"; }); };
        if (!tabs[0]) return copy();
        chrome.tabs.sendMessage(tabs[0].id, { type: "insert", prompt: k.prompt }, function (res) {
          if (chrome.runtime.lastError || !res || !res.ok) return copy();
          window.close();
        });
      });
    };
    list.appendChild(row);
  });
}

var pick = document.getElementById("site");
Object.keys(COACH_SITES).forEach(function (k) { var o = el("option", null, COACH_SITES[k].name); o.value = k; pick.appendChild(o); });
pick.onchange = function () { TRACK = pick.value; openUnit = null; render(); };
document.querySelectorAll(".seg button").forEach(function (b) { b.onclick = function () { tab = b.dataset.tab; render(); }; });
document.getElementById("tips").onclick = function () { load(function () { S.nudges = S.nudges === false; save(); render(); }); };
load(function () {
  if (S.track && COACH_TRACKS[S.track]) TRACK = S.track;
  render();                                   // last-used AI right away; switch if this tab is another AI
  detect(function () { if (pick.value !== TRACK) { openUnit = null; render(); } });
});
